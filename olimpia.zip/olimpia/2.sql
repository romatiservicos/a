-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 12-Abr-2017 às 05:39
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `password` char(40) NOT NULL,
  `secret` char(16) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '1',
  `premdays` int(11) NOT NULL DEFAULT '0',
  `coins` int(12) NOT NULL DEFAULT '0',
  `lastday` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `vipdays` int(11) NOT NULL DEFAULT '0',
  `viplastday` int(10) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '',
  `creation` int(11) NOT NULL DEFAULT '0',
  `vote` int(11) NOT NULL,
  `key` varchar(20) NOT NULL DEFAULT '0',
  `email_new` varchar(255) NOT NULL DEFAULT '',
  `email_new_time` int(11) NOT NULL DEFAULT '0',
  `rlname` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL DEFAULT '',
  `page_access` int(11) NOT NULL DEFAULT '0',
  `email_code` varchar(255) NOT NULL DEFAULT '',
  `next_email` int(11) NOT NULL DEFAULT '0',
  `premium_points` int(11) NOT NULL DEFAULT '0',
  `create_date` int(11) NOT NULL DEFAULT '0',
  `create_ip` int(11) NOT NULL DEFAULT '0',
  `last_post` int(11) NOT NULL DEFAULT '0',
  `flag` varchar(80) NOT NULL DEFAULT '',
  `vip_time` int(11) NOT NULL,
  `guild_points` int(11) NOT NULL DEFAULT '0',
  `guild_points_stats` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `accounts`
--

INSERT INTO `accounts` (`id`, `name`, `password`, `secret`, `type`, `premdays`, `coins`, `lastday`, `vipdays`, `viplastday`, `email`, `creation`, `vote`, `key`, `email_new`, `email_new_time`, `rlname`, `location`, `page_access`, `email_code`, `next_email`, `premium_points`, `create_date`, `create_ip`, `last_post`, `flag`, `vip_time`, `guild_points`, `guild_points_stats`) VALUES
(1, '1', '060d38973b4ba4051fa6ca22f9acd4be7d1557fe', NULL, 1, 0, 0, 0, 0, 0, '', 0, 0, '0', '', 0, '', '', 9999, '', 0, 0, 0, 0, 0, 'unknown', 0, 0, 0),
(8, 'god', '21298df8a3277357ee55b01df9530b535cf08ec1', NULL, 5, 0, 0, 0, 0, 0, '', 1465696163, 0, 'BSLH5EYDNW', '', 0, 'Jonathan', 'SÃ£o Paulo', 9999, '', 0, 99, 0, 0, 1473105428, '', 0, 0, 0),
(9, 'SEMNOME', '7c944696f85ddd6ca7711ed278c59af4573b798c', NULL, 5, 3065, 0, 1491856849, 0, 0, 'semnome@hotmail.com', 1491856849, 0, '', '', 0, '', '', 0, '', 0, 0, 0, -1157399548, 0, 'br', 0, 0, 0),
(10, 'JOAOBALEIA', '4813893d1eaab36a72a8f816015c828e1c129606', NULL, 5, 3064, 0, 1491943350, 0, 0, 'davi.tibia@hotmail.com', 1491856950, 0, '', '', 0, '', '', 0, '', 0, 0, 0, -1157399548, 0, 'br', 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `account_bans`
--

CREATE TABLE `account_bans` (
  `account_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `banned_at` bigint(20) NOT NULL,
  `expires_at` bigint(20) NOT NULL,
  `banned_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `account_ban_history`
--

CREATE TABLE `account_ban_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `banned_at` bigint(20) NOT NULL,
  `expired_at` bigint(20) NOT NULL,
  `banned_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `account_viplist`
--

CREATE TABLE `account_viplist` (
  `account_id` int(11) NOT NULL COMMENT 'id of account whose viplist entry it is',
  `player_id` int(11) NOT NULL COMMENT 'id of target player of viplist entry',
  `description` varchar(128) NOT NULL DEFAULT '',
  `icon` tinyint(2) UNSIGNED NOT NULL DEFAULT '0',
  `notify` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `announcements`
--

CREATE TABLE `announcements` (
  `id` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `text` varchar(255) NOT NULL,
  `date` varchar(20) NOT NULL,
  `author` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `global_storage`
--

CREATE TABLE `global_storage` (
  `key` varchar(32) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guilds`
--

CREATE TABLE `guilds` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ownerid` int(11) NOT NULL,
  `creationdata` int(11) NOT NULL,
  `motd` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `guild_logo` mediumblob,
  `create_ip` int(11) NOT NULL DEFAULT '0',
  `balance` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `last_execute_points` int(11) NOT NULL DEFAULT '0',
  `logo_gfx_name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Acionadores `guilds`
--
DELIMITER $$
CREATE TRIGGER `oncreate_guilds` AFTER INSERT ON `guilds` FOR EACH ROW BEGIN
    INSERT INTO `guild_ranks` (`name`, `level`, `guild_id`) VALUES ('the Leader', 3, NEW.`id`);
    INSERT INTO `guild_ranks` (`name`, `level`, `guild_id`) VALUES ('a Vice-Leader', 2, NEW.`id`);
    INSERT INTO `guild_ranks` (`name`, `level`, `guild_id`) VALUES ('a Member', 1, NEW.`id`);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guildwar_kills`
--

CREATE TABLE `guildwar_kills` (
  `id` int(11) NOT NULL,
  `killer` varchar(50) NOT NULL,
  `target` varchar(50) NOT NULL,
  `killerguild` int(11) NOT NULL DEFAULT '0',
  `targetguild` int(11) NOT NULL DEFAULT '0',
  `warid` int(11) NOT NULL DEFAULT '0',
  `time` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_invites`
--

CREATE TABLE `guild_invites` (
  `player_id` int(11) NOT NULL DEFAULT '0',
  `guild_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_membership`
--

CREATE TABLE `guild_membership` (
  `player_id` int(11) NOT NULL,
  `guild_id` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `nick` varchar(15) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_ranks`
--

CREATE TABLE `guild_ranks` (
  `id` int(11) NOT NULL,
  `guild_id` int(11) NOT NULL COMMENT 'guild',
  `name` varchar(255) NOT NULL COMMENT 'rank name',
  `level` int(11) NOT NULL COMMENT 'rank level - leader, vice, member, maybe something else'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_wars`
--

CREATE TABLE `guild_wars` (
  `id` int(11) NOT NULL,
  `guild1` int(11) NOT NULL DEFAULT '0',
  `guild2` int(11) NOT NULL DEFAULT '0',
  `name1` varchar(255) NOT NULL,
  `name2` varchar(255) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `started` bigint(15) NOT NULL DEFAULT '0',
  `ended` bigint(15) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `houses`
--

CREATE TABLE `houses` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `paid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `warnings` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `rent` int(11) NOT NULL DEFAULT '0',
  `town_id` int(11) NOT NULL DEFAULT '0',
  `bid` int(11) NOT NULL DEFAULT '0',
  `bid_end` int(11) NOT NULL DEFAULT '0',
  `last_bid` int(11) NOT NULL DEFAULT '0',
  `highest_bidder` int(11) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL DEFAULT '0',
  `beds` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `houses`
--

INSERT INTO `houses` (`id`, `owner`, `paid`, `warnings`, `name`, `rent`, `town_id`, `bid`, `bid_end`, `last_bid`, `highest_bidder`, `size`, `beds`) VALUES
(170, 0, 0, 0, 'Baiak House 001', 0, 1, 0, 0, 0, 0, 40, 1),
(171, 0, 0, 0, 'Baiak House 002', 0, 1, 0, 0, 0, 0, 24, 1),
(197, 0, 0, 0, 'Baiak House 028', 0, 1, 0, 0, 0, 0, 40, 1),
(198, 150, 0, 0, 'Baiak House 029', 0, 1, 0, 0, 0, 0, 71, 1),
(199, 151, 0, 0, 'Baiak House 030', 0, 1, 0, 0, 0, 0, 68, 1),
(200, 154, 0, 0, 'Baiak House 031', 0, 1, 0, 0, 0, 0, 65, 1),
(202, 0, 0, 0, 'Baiak House 033', 0, 1, 0, 0, 0, 0, 40, 1),
(203, 0, 0, 0, 'Baiak House 034', 0, 1, 0, 0, 0, 0, 34, 1),
(204, 0, 0, 0, 'Baiak House 035', 0, 1, 0, 0, 0, 0, 35, 1),
(205, 0, 0, 0, 'Baiak House 036', 0, 1, 0, 0, 0, 0, 66, 1),
(207, 0, 0, 0, 'Baiak House 038', 0, 1, 0, 0, 0, 0, 155, 2),
(208, 0, 0, 0, 'Baiak House 039', 0, 1, 0, 0, 0, 0, 48, 1),
(209, 0, 0, 0, 'Baiak House 040', 0, 1, 0, 0, 0, 0, 25, 1),
(210, 0, 0, 0, 'Baiak House 041', 0, 1, 0, 0, 0, 0, 81, 2),
(211, 0, 0, 0, 'Baiak House 042', 0, 1, 0, 0, 0, 0, 95, 0),
(212, 0, 0, 0, 'Baiak House 043', 0, 1, 0, 0, 0, 0, 238, 0),
(213, 0, 0, 0, 'Baiak House 044', 0, 1, 0, 0, 0, 0, 71, 1),
(215, 0, 0, 0, 'Baiak House 046', 0, 1, 0, 0, 0, 0, 93, 1),
(216, 0, 0, 0, 'Baiak House 047', 0, 1, 0, 0, 0, 0, 71, 1),
(217, 0, 0, 0, 'Baiak House 048', 0, 1, 0, 0, 0, 0, 48, 1),
(218, 0, 0, 0, 'Baiak House 049', 0, 1, 0, 0, 0, 0, 28, 1),
(225, 0, 0, 0, 'Baiak House 056', 0, 1, 0, 0, 0, 0, 66, 1),
(226, 0, 0, 0, 'Baiak House 057', 0, 1, 0, 0, 0, 0, 25, 1),
(227, 0, 0, 0, 'Baiak House 058', 0, 1, 0, 0, 0, 0, 30, 1),
(228, 0, 0, 0, 'Baiak House 059', 0, 1, 0, 0, 0, 0, 24, 1),
(229, 0, 0, 0, 'Baiak House 060', 0, 1, 0, 0, 0, 0, 24, 1),
(230, 0, 0, 0, 'Baiak House 061', 0, 1, 0, 0, 0, 0, 43, 1),
(231, 0, 0, 0, 'Baiak House 062', 0, 1, 0, 0, 0, 0, 32, 1),
(232, 0, 0, 0, 'Baiak House 063', 0, 1, 0, 0, 0, 0, 48, 1),
(233, 0, 0, 0, 'Baiak House 064', 0, 1, 0, 0, 0, 0, 2, 0),
(234, 0, 0, 0, 'Baiak House 065', 0, 1, 0, 0, 0, 0, 29, 1),
(235, 0, 0, 0, 'Baiak House 066', 0, 1, 0, 0, 0, 0, 20, 1),
(236, 0, 0, 0, 'Baiak House 067', 0, 1, 0, 0, 0, 0, 30, 1),
(237, 0, 0, 0, 'Baiak House 068', 0, 1, 0, 0, 0, 0, 39, 1),
(238, 0, 0, 0, 'Baiak House 069', 0, 1, 0, 0, 0, 0, 50, 1),
(1901, 0, 0, 0, 'Baiak House 070', 0, 1, 0, 0, 0, 0, 45, 1),
(1902, 0, 0, 0, 'Baiak House 071', 0, 1, 0, 0, 0, 0, 40, 1),
(1903, 0, 0, 0, 'Baiak House 072', 0, 1, 0, 0, 0, 0, 43, 1),
(1904, 0, 0, 0, 'Baiak House 073', 0, 1, 0, 0, 0, 0, 50, 1),
(1905, 0, 0, 0, 'Baiak House 074', 0, 1, 0, 0, 0, 0, 37, 1),
(1906, 0, 0, 0, 'Baiak House 075', 0, 1, 0, 0, 0, 0, 33, 1),
(1908, 0, 0, 0, 'Baiak House 076', 0, 1, 0, 0, 0, 0, 50, 1),
(1909, 0, 0, 0, 'Baiak House 077', 0, 1, 0, 0, 0, 0, 40, 1),
(1910, 0, 0, 0, 'Baiak House 078', 0, 1, 0, 0, 0, 0, 61, 1),
(1911, 0, 0, 0, 'Baiak House 079', 0, 1, 0, 0, 0, 0, 84, 1),
(1912, 0, 0, 0, 'Baiak House 080', 0, 1, 0, 0, 0, 0, 50, 1),
(1913, 0, 0, 0, 'Baiak House 081', 0, 1, 0, 0, 0, 0, 70, 1),
(1914, 0, 0, 0, 'Baiak House 082', 0, 1, 0, 0, 0, 0, 70, 1),
(1915, 0, 0, 0, 'Baiak House 083', 0, 1, 0, 0, 0, 0, 80, 1),
(1916, 0, 0, 0, 'Baiak House 084', 0, 1, 0, 0, 0, 0, 54, 1),
(1917, 0, 0, 0, 'Baiak House 085', 0, 1, 0, 0, 0, 0, 63, 1),
(1918, 0, 0, 0, 'Baiak House 086', 0, 1, 0, 0, 0, 0, 12, 1),
(1919, 0, 0, 0, 'Baiak House 087', 0, 1, 0, 0, 0, 0, 12, 1),
(1920, 0, 0, 0, 'Baiak House 088', 0, 1, 0, 0, 0, 0, 12, 1),
(1921, 0, 0, 0, 'Baiak House 089', 0, 1, 0, 0, 0, 0, 12, 1),
(1922, 0, 0, 0, 'Baiak House 090', 0, 1, 0, 0, 0, 0, 12, 1),
(1923, 0, 0, 0, 'Baiak House 091', 0, 1, 0, 0, 0, 0, 12, 1),
(1924, 0, 0, 0, 'Baiak House 092', 0, 1, 0, 0, 0, 0, 12, 1),
(1925, 0, 0, 0, 'Baiak House 093', 0, 1, 0, 0, 0, 0, 12, 1),
(1926, 0, 0, 0, 'Baiak House 094', 0, 1, 0, 0, 0, 0, 15, 1),
(1927, 0, 0, 0, 'Baiak House 095', 0, 1, 0, 0, 0, 0, 15, 1),
(1928, 0, 0, 0, 'Baiak House 096', 0, 1, 0, 0, 0, 0, 12, 1),
(1929, 0, 0, 0, 'Baiak House 097', 0, 1, 0, 0, 0, 0, 12, 1),
(1930, 0, 0, 0, 'Baiak House 098', 0, 1, 0, 0, 0, 0, 12, 1),
(1931, 0, 0, 0, 'Baiak House 099', 0, 1, 0, 0, 0, 0, 12, 1),
(1932, 0, 0, 0, 'Baiak House 100', 0, 1, 0, 0, 0, 0, 12, 1),
(1933, 0, 0, 0, 'Baiak House 101', 0, 1, 0, 0, 0, 0, 12, 1),
(1935, 0, 0, 0, 'Baiak House 026', 0, 1, 0, 0, 0, 0, 58, 1),
(1937, 0, 0, 0, 'Baiak House 051', 0, 1, 0, 0, 0, 0, 40, 1),
(1938, 0, 0, 0, 'Baiak House 052', 0, 1, 0, 0, 0, 0, 44, 1),
(1939, 0, 0, 0, 'Baiak House 050', 0, 1, 0, 0, 0, 0, 28, 1),
(1940, 0, 0, 0, 'Baiak House 053', 0, 1, 0, 0, 0, 0, 58, 2),
(1941, 0, 0, 0, 'Baiak House 054', 0, 1, 0, 0, 0, 0, 37, 1),
(1942, 0, 0, 0, 'Baiak House 055', 0, 1, 0, 0, 0, 0, 108, 2),
(1943, 0, 0, 0, 'Baiak House 003', 0, 1, 0, 0, 0, 0, 24, 1),
(1944, 0, 0, 0, 'Baiak House 004', 0, 1, 0, 0, 0, 0, 24, 1),
(1945, 0, 0, 0, 'Baiak Castle', 0, 1, 0, 0, 0, 0, 220, 1),
(1946, 0, 0, 0, 'Baiak House 102', 0, 1, 0, 0, 0, 0, 90, 1),
(1950, 0, 0, 0, 'Baiak House 008', 0, 1, 0, 0, 0, 0, 30, 1),
(1951, 0, 0, 0, 'Baiak House 009', 0, 1, 0, 0, 0, 0, 40, 1),
(1952, 0, 0, 0, 'Baiak House 011', 0, 1, 0, 0, 0, 0, 42, 1),
(1953, 0, 0, 0, 'Baiak House 012', 0, 1, 0, 0, 0, 0, 56, 1),
(1954, 0, 0, 0, 'Baiak House 013', 0, 1, 0, 0, 0, 0, 50, 1),
(1955, 0, 0, 0, 'Baiak House 014', 0, 1, 0, 0, 0, 0, 63, 1),
(1956, 0, 0, 0, 'Baiak House 015', 0, 1, 0, 0, 0, 0, 45, 1),
(1957, 0, 0, 0, 'Baiak House 016', 0, 1, 0, 0, 0, 0, 46, 1),
(1958, 0, 0, 0, 'Baiak House 017', 0, 1, 0, 0, 0, 0, 89, 1),
(1959, 0, 0, 0, 'Baiak House 018', 0, 1, 0, 0, 0, 0, 126, 1),
(1960, 0, 0, 0, 'Baiak House 019', 0, 1, 0, 0, 0, 0, 81, 1),
(1961, 0, 0, 0, 'Baiak House 020', 0, 1, 0, 0, 0, 0, 90, 1),
(1962, 0, 0, 0, 'Baiak House 021', 0, 1, 0, 0, 0, 0, 88, 1),
(1963, 0, 0, 0, 'Baiak House 022', 0, 1, 0, 0, 0, 0, 102, 1),
(1964, 0, 0, 0, 'Baiak House 023', 0, 1, 0, 0, 0, 0, 100, 1),
(1965, 0, 0, 0, 'Baiak House 024', 0, 1, 0, 0, 0, 0, 79, 1),
(1966, 0, 0, 0, 'Baiak House 025', 0, 1, 0, 0, 0, 0, 90, 1),
(1967, 0, 0, 0, 'Baiak House 027', 0, 1, 0, 0, 0, 0, 72, 1),
(1968, 0, 0, 0, 'Baiak House 103', 0, 1, 0, 0, 0, 0, 312, 0),
(1969, 0, 0, 0, 'Baiak House 006', 0, 1, 0, 0, 0, 0, 23, 1),
(1970, 0, 0, 0, 'Baiak House 007', 0, 1, 0, 0, 0, 0, 38, 1),
(1971, 0, 0, 0, 'Baiak House 010', 0, 1, 0, 0, 0, 0, 18, 0),
(1972, 0, 0, 0, 'BAIAK new house 104', 0, 1, 0, 0, 0, 0, 29, 1),
(1973, 0, 0, 0, 'BAIAK new house 105', 0, 1, 0, 0, 0, 0, 26, 1),
(1974, 0, 0, 0, 'BAIAK new house 106', 0, 1, 0, 0, 0, 0, 26, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `house_lists`
--

CREATE TABLE `house_lists` (
  `house_id` int(11) NOT NULL,
  `listid` int(11) NOT NULL,
  `list` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `house_lists`
--

INSERT INTO `house_lists` (`house_id`, `listid`, `list`) VALUES
(198, 257, 'warrior');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ip_bans`
--

CREATE TABLE `ip_bans` (
  `ip` int(10) UNSIGNED NOT NULL,
  `reason` varchar(255) NOT NULL,
  `banned_at` bigint(20) NOT NULL,
  `expires_at` bigint(20) NOT NULL,
  `banned_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `live_casts`
--

CREATE TABLE `live_casts` (
  `player_id` int(11) NOT NULL,
  `cast_name` varchar(255) NOT NULL,
  `password` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `spectators` smallint(5) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `market_history`
--

CREATE TABLE `market_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `player_id` int(11) NOT NULL,
  `sale` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` int(10) UNSIGNED NOT NULL,
  `amount` smallint(5) UNSIGNED NOT NULL,
  `price` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `expires_at` bigint(20) UNSIGNED NOT NULL,
  `inserted` bigint(20) UNSIGNED NOT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `market_offers`
--

CREATE TABLE `market_offers` (
  `id` int(10) UNSIGNED NOT NULL,
  `player_id` int(11) NOT NULL,
  `sale` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` int(10) UNSIGNED NOT NULL,
  `amount` smallint(5) UNSIGNED NOT NULL,
  `created` bigint(20) UNSIGNED NOT NULL,
  `anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `price` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `players`
--

CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '1',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '1',
  `vocation` int(11) NOT NULL DEFAULT '0',
  `health` int(11) NOT NULL DEFAULT '150',
  `healthmax` int(11) NOT NULL DEFAULT '150',
  `experience` bigint(20) NOT NULL DEFAULT '0',
  `lookbody` int(11) NOT NULL DEFAULT '0',
  `lookfeet` int(11) NOT NULL DEFAULT '0',
  `lookhead` int(11) NOT NULL DEFAULT '0',
  `looklegs` int(11) NOT NULL DEFAULT '0',
  `looktype` int(11) NOT NULL DEFAULT '136',
  `lookaddons` int(11) NOT NULL DEFAULT '0',
  `maglevel` int(11) NOT NULL DEFAULT '0',
  `mana` int(11) NOT NULL DEFAULT '0',
  `manamax` int(11) NOT NULL DEFAULT '0',
  `manaspent` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `soul` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `town_id` int(11) NOT NULL DEFAULT '0',
  `posx` int(11) NOT NULL DEFAULT '0',
  `posy` int(11) NOT NULL DEFAULT '0',
  `posz` int(11) NOT NULL DEFAULT '0',
  `conditions` blob NOT NULL,
  `cap` int(11) NOT NULL DEFAULT '0',
  `sex` int(11) NOT NULL DEFAULT '0',
  `lastlogin` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `lastip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `save` tinyint(1) NOT NULL DEFAULT '1',
  `skull` tinyint(1) NOT NULL DEFAULT '0',
  `skulltime` int(11) NOT NULL DEFAULT '0',
  `lastlogout` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `blessings` tinyint(2) NOT NULL DEFAULT '0',
  `onlinetime` int(11) NOT NULL DEFAULT '0',
  `deletion` bigint(15) NOT NULL DEFAULT '0',
  `balance` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `offlinetraining_time` smallint(5) UNSIGNED NOT NULL DEFAULT '43200',
  `offlinetraining_skill` int(11) NOT NULL DEFAULT '-1',
  `stamina` smallint(5) UNSIGNED NOT NULL DEFAULT '2520',
  `skill_fist` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_fist_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_club` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_club_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_sword` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_sword_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_axe` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_axe_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_dist` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_dist_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_shielding` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_shielding_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_fishing` int(10) UNSIGNED NOT NULL DEFAULT '10',
  `skill_fishing_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `create_ip` int(11) NOT NULL DEFAULT '0',
  `create_date` int(11) NOT NULL DEFAULT '0',
  `hide_char` int(11) NOT NULL DEFAULT '0',
  `cast` tinyint(1) NOT NULL DEFAULT '0',
  `skill_critical_hit_chance` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skill_critical_hit_chance_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_critical_hit_damage` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skill_critical_hit_damage_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_life_leech_chance` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skill_life_leech_chance_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_life_leech_amount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skill_life_leech_amount_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_mana_leech_chance` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skill_mana_leech_chance_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_mana_leech_amount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skill_mana_leech_amount_tries` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_criticalhit_chance` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_criticalhit_damage` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_lifeleech_chance` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_lifeleech_amount` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_manaleech_chance` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `skill_manaleech_amount` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `marriage_status` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `former` varchar(255) NOT NULL DEFAULT '-',
  `resets` int(11) NOT NULL DEFAULT '0',
  `frags` int(11) NOT NULL DEFAULT '0',
  `deaths` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `players`
--

INSERT INTO `players` (`id`, `name`, `group_id`, `account_id`, `level`, `vocation`, `health`, `healthmax`, `experience`, `lookbody`, `lookfeet`, `lookhead`, `looklegs`, `looktype`, `lookaddons`, `maglevel`, `mana`, `manamax`, `manaspent`, `soul`, `town_id`, `posx`, `posy`, `posz`, `conditions`, `cap`, `sex`, `lastlogin`, `lastip`, `save`, `skull`, `skulltime`, `lastlogout`, `blessings`, `onlinetime`, `deletion`, `balance`, `offlinetraining_time`, `offlinetraining_skill`, `stamina`, `skill_fist`, `skill_fist_tries`, `skill_club`, `skill_club_tries`, `skill_sword`, `skill_sword_tries`, `skill_axe`, `skill_axe_tries`, `skill_dist`, `skill_dist_tries`, `skill_shielding`, `skill_shielding_tries`, `skill_fishing`, `skill_fishing_tries`, `deleted`, `description`, `comment`, `create_ip`, `create_date`, `hide_char`, `cast`, `skill_critical_hit_chance`, `skill_critical_hit_chance_tries`, `skill_critical_hit_damage`, `skill_critical_hit_damage_tries`, `skill_life_leech_chance`, `skill_life_leech_chance_tries`, `skill_life_leech_amount`, `skill_life_leech_amount_tries`, `skill_mana_leech_chance`, `skill_mana_leech_chance_tries`, `skill_mana_leech_amount`, `skill_mana_leech_amount_tries`, `skill_criticalhit_chance`, `skill_criticalhit_damage`, `skill_lifeleech_chance`, `skill_lifeleech_amount`, `skill_manaleech_chance`, `skill_manaleech_amount`, `marriage_status`, `former`, `resets`, `frags`, `deaths`) VALUES
(1, 'Rook Sample', 1, 1, 8, 0, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 0, 35, 35, 0, 0, 2, 32104, 32191, 6, '', 400, 0, 1407021967, 1793873073, 1, 0, 0, 1407021968, 0, 203, 0, 0, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(2, 'Sorcerer Sample', 1, 1, 8, 1, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 0, 35, 35, 0, 100, 1, 159, 49, 7, '', 800, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(3, 'Druid Sample', 1, 1, 8, 2, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 0, 35, 35, 0, 100, 1, 159, 49, 7, 0x010004000002ffffffff0360ea00001a001b00000000fe, 800, 0, 1407021516, 255183537, 1, 0, 0, 1407021548, 0, 32, 0, 0, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(4, 'Paladin Sample', 1, 1, 8, 3, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 0, 35, 35, 0, 100, 1, 159, 49, 7, '', 800, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(5, 'Knight Sample', 1, 1, 8, 4, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 0, 35, 35, 0, 100, 1, 159, 49, 7, '', 800, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(150, 'XXX', 5, 8, 8, 2, 180, 180, 4200, 106, 62, 96, 80, 129, 3, 0, 15, 35, 200, 100, 1, 158, 54, 7, 0x010020000002ffffffff03f0c003001a001b0000000004b80b0000056400000006b80b000007c8000000fe, 400, 1, 1491967669, 16777343, 1, 0, 0, 1491967682, 63, 415114, 0, 199501, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', 2147483647, 1472930428, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(151, 'Semnome', 1, 9, 278, 8, 4191, 4230, 352885200, 0, 95, 78, 115, 128, 0, 10, 1385, 1385, 10763400, 138, 1, 158, 66, 7, 0x010100000002000000000308c901001a001b00000000080119000000000aa00f0000e9ffffff881300000a88130000eaffffff881300000a88130000ebffffff881300000a88130000ecffffff881300000a88130000edffffff881300000a88130000eeffffff881300000a88130000efffffff881300000a88130000f0ffffff881300000a88130000f1ffffff881300000a88130000f2ffffff881300000a88130000f3ffffff881300000a88130000f4ffffff881300000a88130000f5ffffff881300000a88130000f6ffffff881300000a88130000f7ffffff881300000a88130000f8ffffff881300000a88130000f9ffffff881300000a88130000faffffff881300000a88130000fbffffff881300000a88130000fcffffff881300000a88130000fdffffff881300000a88130000feffffff881300000a88130000ffffffff88130000fe010040000002ffffffff03606102001a001b00000000150100000014983a0000fe010004000002ffffffff0390e200001a001b00000000fe010020000002ffffffff0340dd0a001a001b0000000004b80b0000059001000006b80b00000796000000fe, 7550, 1, 1491866227, 75236283, 1, 0, 0, 1491866229, 31, 66187, 0, 0, 40184, 2, 2495, 10, 0, 10, 0, 97, 188263, 10, 0, 10, 0, 70, 11145, 10, 0, 0, '', '', -1157399548, 1491856865, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(152, 'Mesiah', 1, 9, 8, 1, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 99, 35, 35, 3161180, 100, 1, 146, 48, 8, '', 800, 1, 1491866222, 75236283, 1, 0, 0, 1491866224, 31, 33, 0, 0, 35214, 13, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 28, 104029, 10, 0, 0, '', '', -1157399548, 1491856884, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(153, 'Arrogante', 1, 10, 516, 7, 5260, 5260, 2272503924, 0, 95, 78, 115, 128, 0, 17, 6688, 7655, 4480, 100, 1, 361, 34, 7, 0x010020000002ffffffff0358f705001a001b0000000004b80b0000055e01000006b80b000007fa000000fe010004000002ffffffff0360ea00001a001b00000000fe0101000000020000000003b8f902001a001b00000000080119000000000a88130000d9ffffff881300000a88130000daffffff881300000a88130000dbffffff881300000a88130000dcffffff881300000a88130000ddffffff881300000a88130000deffffff881300000a88130000dfffffff881300000a88130000e0ffffff881300000a88130000e1ffffff881300000a88130000e2ffffff881300000a88130000e3ffffff881300000a88130000e4ffffff881300000a88130000e5ffffff881300000a88130000e6ffffff881300000a88130000e7ffffff881300000a88130000e8ffffff881300000a88130000e9ffffff881300000a88130000eaffffff881300000a88130000ebffffff881300000a88130000ecffffff881300000a88130000edffffff881300000a88130000eeffffff881300000a88130000efffffff881300000a88130000f0ffffff881300000a88130000f1ffffff881300000a88130000f2ffffff881300000a88130000f3ffffff881300000a88130000f4ffffff881300000a88130000f5ffffff881300000a88130000f6ffffff881300000a88130000f7ffffff881300000a88130000f8ffffff881300000a88130000f9ffffff881300000a88130000faffffff881300000a88130000fbffffff881300000a88130000fcffffff881300000a88130000fdffffff881300000a88130000feffffff881300000a88130000ffffffff88130000fe0102000000020000000003581501001a001b00000000080019000000000ad0070000f6ffffff102700000a10270000f6ffffff102700000a10270000f6ffffff102700000a10270000f6ffffff102700000a10270000f6ffffff102700000a10270000f6ffffff102700000a10270000f6ffffff10270000fe0120000000020000000003307500001a001b000000000b89feffff0c9a9999be0d000000000e9a9999be0f00000000fe010400000002000000000388d709001a001b00000000080119000000000a401f0000f2ffffff102700000a10270000f2ffffff102700000a10270000f3ffffff102700000a10270000f4ffffff102700000a10270000f4ffffff102700000a10270000f5ffffff102700000a10270000f5ffffff102700000a10270000f6ffffff102700000a10270000f6ffffff102700000a10270000f7ffffff102700000a10270000f7ffffff102700000a10270000f8ffffff102700000a10270000f8ffffff102700000a10270000f9ffffff102700000a10270000f9ffffff102700000a10270000f9ffffff102700000a10270000faffffff102700000a10270000faffffff102700000a10270000faffffff102700000a10270000fbffffff102700000a10270000fbffffff102700000a10270000fbffffff102700000a10270000fbffffff102700000a10270000fcffffff102700000a10270000fcffffff102700000a10270000fcffffff102700000a10270000fcffffff102700000a10270000fcffffff102700000a10270000fdffffff102700000a10270000fdffffff102700000a10270000fdffffff102700000a10270000fdffffff102700000a10270000fdffffff102700000a10270000fdffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000feffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff102700000a10270000ffffffff10270000fe, 10960, 1, 1491967603, 688892096, 1, 0, 0, 1491968175, 31, 3674, 0, 0, 43200, -1, 2520, 28, 1300, 10, 0, 10, 0, 10, 0, 85, 17570, 10, 0, 10, 0, 0, '', '', -1157399548, 1491856989, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 2, 0),
(154, 'Fustrado', 1, 10, 516, 5, 2549, 2720, 2273085450, 0, 95, 78, 115, 128, 0, 69, 11, 15275, 236700, 100, 1, 160, 56, 8, 0x010004000002ffffffff0360ea00001a001b00000000fe, 5880, 1, 1491939188, 75236283, 1, 0, 0, 1491940189, 31, 2726, 0, 0, 43200, -1, 2518, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 22, 11055, 10, 0, 0, '', '', -1157399548, 1491857219, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(155, 'Godsemnome', 5, 9, 8, 2, 180, 180, 4200, 0, 95, 78, 115, 128, 0, 0, 35, 35, 0, 100, 1, 155, 61, 7, '', 800, 1, 1491866231, 75236283, 1, 0, 0, 1491866240, 31, 1677, 0, 0, 43200, -1, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 0, '', '', -1157399548, 1491857239, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(156, 'Nao Loguei Aind', 1, 9, 24, 2, 260, 260, 184200, 0, 95, 78, 115, 128, 0, 100, 515, 515, 75240, 100, 1, 146, 48, 8, 0x010004000002ffffffff03b0b300001a001b00000000fe010020000002ffffffff03888402001a001b0000000004b80b0000056400000006b80b000007c8000000fe, 960, 1, 1491866225, 75236283, 1, 0, 0, 1491866226, 31, 43, 0, 0, 34923, 13, 2520, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 28, 118629, 10, 0, 0, '', '', -1157399548, 1491857716, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0),
(157, 'Warrior', 1, 8, 542, 8, 8190, 8190, 2638310533, 114, 0, 79, 76, 699, 0, 14, 2705, 2705, 1806676754, 102, 1, 154, 49, 7, '', 14150, 1, 1491968042, 16777343, 1, 0, 0, 1491968175, 0, 6310, 0, 0, 43200, -1, 2518, 10, 0, 10, 0, 120, 295955, 39, 475, 10, 0, 68, 18485, 10, 0, 0, '', '', 0, 1491876900, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `players_online`
--

CREATE TABLE `players_online` (
  `player_id` int(11) NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `players_online`
--

INSERT INTO `players_online` (`player_id`) VALUES
(268435459),
(268435460);

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_deaths`
--

CREATE TABLE `player_deaths` (
  `player_id` int(11) NOT NULL,
  `time` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '1',
  `killed_by` varchar(255) NOT NULL,
  `is_player` tinyint(1) NOT NULL DEFAULT '1',
  `mostdamage_by` varchar(100) NOT NULL,
  `mostdamage_is_player` tinyint(1) NOT NULL DEFAULT '0',
  `unjustified` tinyint(1) NOT NULL DEFAULT '0',
  `mostdamage_unjustified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `player_deaths`
--

INSERT INTO `player_deaths` (`player_id`, `time`, `level`, `killed_by`, `is_player`, `mostdamage_by`, `mostdamage_is_player`, `unjustified`, `mostdamage_unjustified`) VALUES
(153, 1491938768, 8, 'drillworm', 0, 'drillworm', 0, 0, 0),
(157, 1491967739, 549, 'Arrogante', 1, 'Arrogante', 1, 1, 0),
(157, 1491968028, 547, 'Arrogante', 1, 'Arrogante', 1, 1, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_depotitems`
--

CREATE TABLE `player_depotitems` (
  `player_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL COMMENT 'any given range eg 0-100 will be reserved for depot lockers and all > 100 will be then normal items inside depots',
  `pid` int(11) NOT NULL DEFAULT '0',
  `itemtype` smallint(6) NOT NULL,
  `count` smallint(5) NOT NULL DEFAULT '0',
  `attributes` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_inboxitems`
--

CREATE TABLE `player_inboxitems` (
  `player_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0',
  `itemtype` smallint(6) NOT NULL,
  `count` smallint(5) NOT NULL DEFAULT '0',
  `attributes` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_items`
--

CREATE TABLE `player_items` (
  `player_id` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `itemtype` smallint(6) NOT NULL DEFAULT '0',
  `count` smallint(5) NOT NULL DEFAULT '0',
  `attributes` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `player_items`
--

INSERT INTO `player_items` (`player_id`, `pid`, `sid`, `itemtype`, `count`, `attributes`) VALUES
(152, 11, 101, 26052, 1, ''),
(156, 1, 101, 8820, 1, ''),
(156, 2, 102, 2661, 1, ''),
(156, 3, 103, 1988, 1, ''),
(156, 4, 104, 8819, 1, ''),
(156, 5, 105, 2175, 1, ''),
(156, 6, 106, 2182, 1, ''),
(156, 7, 107, 2468, 1, ''),
(156, 8, 108, 2643, 1, ''),
(156, 11, 109, 26052, 1, ''),
(156, 103, 110, 2160, 12, 0x0f0c),
(156, 103, 111, 18559, 1, ''),
(156, 103, 112, 7620, 5, 0x0f05),
(156, 103, 113, 2152, 20, 0x0f14),
(151, 3, 101, 2365, 1, ''),
(151, 4, 102, 25174, 1, ''),
(151, 5, 103, 12644, 1, ''),
(151, 7, 104, 15412, 1, ''),
(151, 8, 105, 26133, 1, ''),
(151, 11, 106, 26052, 1, ''),
(151, 101, 107, 2179, 1, ''),
(151, 101, 108, 2195, 1, ''),
(151, 101, 109, 2520, 1, ''),
(151, 101, 110, 2498, 1, ''),
(151, 101, 111, 2494, 1, ''),
(151, 101, 112, 2528, 1, ''),
(151, 101, 113, 2396, 1, 0x160100),
(151, 101, 114, 2528, 1, ''),
(151, 101, 115, 2528, 1, ''),
(151, 101, 116, 2498, 1, ''),
(151, 101, 117, 2492, 1, ''),
(151, 101, 118, 7402, 1, ''),
(151, 101, 119, 2396, 1, 0x160100),
(151, 101, 120, 2498, 1, ''),
(151, 101, 121, 2528, 1, ''),
(151, 101, 122, 2392, 1, ''),
(151, 101, 123, 2392, 1, ''),
(151, 101, 124, 1988, 1, ''),
(151, 124, 125, 24783, 1, 0x1068402a001101),
(151, 124, 126, 25909, 1, 0x10a02429031101),
(151, 124, 127, 26184, 1, 0x10181311001101),
(151, 124, 128, 26190, 1, 0x10702e11001101),
(151, 124, 129, 1988, 1, ''),
(151, 124, 130, 1988, 1, ''),
(151, 124, 131, 25910, 1, 0x10001529031101),
(151, 124, 132, 15413, 1, ''),
(151, 124, 133, 2160, 9, 0x0f09),
(151, 124, 134, 7620, 1, 0x0f01),
(151, 124, 135, 26031, 1, 0x0f01),
(151, 124, 136, 15515, 2, 0x0f02),
(151, 129, 137, 26190, 1, 0x10d87610001101),
(151, 129, 138, 26190, 1, 0x10788610001101),
(151, 129, 139, 26190, 1, 0x10788610001101),
(151, 129, 140, 26190, 1, 0x10908210001101),
(151, 129, 141, 26190, 1, 0x10908210001101),
(151, 129, 142, 26190, 1, 0x10a87e10001101),
(151, 129, 143, 26190, 1, 0x10a87e10001101),
(151, 129, 144, 26190, 1, 0x10c07a10001101),
(151, 129, 145, 26190, 1, 0x10c07a10001101),
(151, 129, 146, 26190, 1, 0x10d87610001101),
(151, 129, 147, 26190, 1, 0x10d87610001101),
(151, 129, 148, 26190, 1, 0x10e04b10001101),
(151, 129, 149, 26190, 1, 0x10985710001101),
(151, 129, 150, 26190, 1, 0x10386710001101),
(151, 129, 151, 26190, 1, 0x10506310001101),
(151, 129, 152, 26190, 1, 0x10685f10001101),
(151, 129, 153, 26190, 1, 0x10685f10001101),
(151, 129, 154, 26190, 1, 0x10805b10001101),
(151, 129, 155, 26190, 1, 0x10805b10001101),
(151, 129, 156, 26190, 1, 0x10985710001101),
(151, 130, 157, 26184, 1, 0x1008ec10001101),
(151, 130, 158, 26184, 1, 0x10780311001101),
(151, 130, 159, 26184, 1, 0x1090ff10001101),
(151, 130, 160, 26184, 1, 0x1090ff10001101),
(151, 130, 161, 26184, 1, 0x10a8fb10001101),
(151, 130, 162, 26184, 1, 0x10a8fb10001101),
(151, 130, 163, 26184, 1, 0x10c0f710001101),
(151, 130, 164, 26184, 1, 0x10c0f710001101),
(151, 130, 165, 26184, 1, 0x10d8f310001101),
(151, 130, 166, 26184, 1, 0x10d8f310001101),
(151, 130, 167, 26184, 1, 0x10f0ef10001101),
(151, 130, 168, 26184, 1, 0x10f0ef10001101),
(151, 130, 169, 26184, 1, 0x1008ec10001101),
(151, 130, 170, 26184, 1, 0x10600d10001101),
(151, 130, 171, 26184, 1, 0x10b8a510001101),
(151, 130, 172, 26184, 1, 0x10b0d010001101),
(151, 130, 173, 26184, 1, 0x1070b110001101),
(151, 130, 174, 26184, 1, 0x1098d410001101),
(151, 130, 175, 26184, 1, 0x1098d410001101),
(151, 130, 176, 26184, 1, 0x10b0d010001101),
(155, 1, 101, 2493, 1, ''),
(155, 3, 102, 10518, 1, ''),
(155, 4, 103, 2494, 1, ''),
(155, 5, 104, 2520, 1, ''),
(155, 6, 105, 2421, 1, ''),
(155, 7, 106, 2495, 1, ''),
(155, 8, 107, 9932, 1, 0x10106035001101),
(155, 11, 108, 26052, 1, ''),
(154, 1, 101, 8820, 1, ''),
(154, 2, 102, 2661, 1, ''),
(154, 3, 103, 1988, 1, ''),
(154, 4, 104, 8819, 1, ''),
(154, 5, 105, 2175, 1, ''),
(154, 6, 106, 25917, 1, 0x10a86a2b031101),
(154, 7, 107, 2468, 1, ''),
(154, 8, 108, 2643, 1, ''),
(154, 11, 109, 26052, 1, ''),
(154, 103, 110, 2152, 20, 0x0f14),
(154, 103, 111, 2365, 1, ''),
(154, 103, 112, 2160, 30, 0x0f1e),
(154, 103, 113, 18559, 1, ''),
(154, 103, 114, 7620, 5, 0x0f05),
(150, 3, 101, 1988, 1, ''),
(150, 6, 102, 25990, 1, 0x10608f95021101),
(150, 7, 103, 18405, 1, ''),
(150, 10, 104, 6529, 1, 0x0f01),
(150, 11, 105, 26052, 1, ''),
(150, 101, 106, 18413, 80, 0x0f50),
(150, 101, 107, 2160, 22, 0x0f16),
(153, 2, 101, 2173, 1, 0x160100),
(153, 3, 102, 2365, 1, ''),
(153, 6, 103, 25916, 1, 0x10b00420031101),
(153, 10, 104, 6529, 1, 0x0f01),
(153, 11, 105, 26052, 1, ''),
(153, 102, 106, 2789, 96, 0x0f60),
(153, 102, 107, 2160, 29, 0x0f1d),
(157, 3, 101, 1987, 1, ''),
(157, 4, 102, 2465, 1, ''),
(157, 6, 103, 25922, 1, 0x105815ef021101),
(157, 7, 104, 2478, 1, ''),
(157, 8, 105, 2643, 1, ''),
(157, 11, 106, 26052, 1, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_killers`
--

CREATE TABLE `player_killers` (
  `kill_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_kills`
--

CREATE TABLE `player_kills` (
  `player_id` int(11) NOT NULL,
  `time` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `target` int(11) NOT NULL,
  `unavenged` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `player_kills`
--

INSERT INTO `player_kills` (`player_id`, `time`, `target`, `unavenged`) VALUES
(153, 1491967739, 157, 1),
(153, 1491968028, 157, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_namelocks`
--

CREATE TABLE `player_namelocks` (
  `player_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `namelocked_at` bigint(20) NOT NULL,
  `namelocked_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_rewards`
--

CREATE TABLE `player_rewards` (
  `player_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0',
  `itemtype` smallint(6) NOT NULL,
  `count` smallint(5) NOT NULL DEFAULT '0',
  `attributes` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_spells`
--

CREATE TABLE `player_spells` (
  `player_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_storage`
--

CREATE TABLE `player_storage` (
  `player_id` int(11) NOT NULL DEFAULT '0',
  `key` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `value` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `player_storage`
--

INSERT INTO `player_storage` (`player_id`, `key`, `value`) VALUES
(150, 12940, 0),
(150, 32143, 1),
(150, 48900, 0),
(150, 48901, 100),
(150, 48902, 0),
(150, 50000, 1),
(150, 50722, 1491967679),
(150, 123654, 0),
(150, 789457, 0),
(150, 10002011, 104),
(151, 6051, 1),
(151, 6071, 1),
(151, 12940, 0),
(151, 30018, 1),
(151, 32143, 16),
(151, 48900, 0),
(151, 48901, 0),
(151, 50000, 1),
(151, 50722, 1491866237),
(151, 54776, 1),
(151, 54779, 1),
(151, 54780, 1),
(151, 123654, 0),
(151, 789457, 0),
(152, 12940, 0),
(152, 48900, 0),
(152, 48901, 0),
(152, 50000, 1),
(152, 50722, 1491866232),
(152, 123654, 0),
(152, 789457, 0),
(153, 12940, 0),
(153, 30018, 1),
(153, 48900, 20),
(153, 48901, 99),
(153, 50000, 1),
(153, 50722, 0),
(153, 54776, 1),
(153, 54779, 1),
(153, 54780, 1),
(153, 123654, 0),
(153, 789457, 0),
(154, 12940, 0),
(154, 30018, 1),
(154, 32143, 1),
(154, 48900, 0),
(154, 48901, 0),
(154, 50000, 1),
(154, 50722, 0),
(154, 54776, 1),
(154, 54779, 1),
(154, 54780, 1),
(154, 123654, 0),
(154, 789457, 0),
(155, 12940, 0),
(155, 48900, 0),
(155, 48901, 100),
(155, 50000, 1),
(155, 50722, 0),
(155, 123654, 0),
(155, 789457, 0),
(156, 12940, 0),
(156, 48900, 0),
(156, 48901, 0),
(156, 50000, 1),
(156, 50722, 1491866235),
(156, 54776, 1),
(156, 54778, 1),
(156, 123654, 0),
(156, 789457, 0),
(157, 12940, 0),
(157, 30018, 1),
(157, 32143, 3),
(157, 48900, 100),
(157, 48901, 100),
(157, 48902, 100),
(157, 50000, 1),
(157, 50722, 0),
(157, 54776, 1),
(157, 54779, 1),
(157, 54780, 1),
(157, 123654, 0),
(157, 789457, 0),
(157, 10002001, 65536),
(157, 10002011, 17);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sellchar`
--

CREATE TABLE `sellchar` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `vocation` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `status` varchar(40) NOT NULL,
  `oldid` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `server_config`
--

CREATE TABLE `server_config` (
  `config` varchar(50) NOT NULL,
  `value` varchar(256) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `server_config`
--

INSERT INTO `server_config` (`config`, `value`) VALUES
('db_version', '24'),
('motd_hash', 'c98416407024e84418de10f69fac77fac27ca4f2'),
('motd_num', '4'),
('players_record', '3');

-- --------------------------------------------------------

--
-- Estrutura da tabela `store_history`
--

CREATE TABLE `store_history` (
  `account_id` int(11) NOT NULL,
  `mode` smallint(2) NOT NULL DEFAULT '0',
  `description` varchar(3500) NOT NULL,
  `coin_amount` int(12) NOT NULL,
  `time` bigint(20) UNSIGNED NOT NULL,
  `timestamp` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `coins` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `store_history`
--

INSERT INTO `store_history` (`account_id`, `mode`, `description`, `coin_amount`, `time`, `timestamp`, `id`, `coins`) VALUES
(8, 0, 'War Horse', 0, 1491876941, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tile_store`
--

CREATE TABLE `tile_store` (
  `house_id` int(11) NOT NULL,
  `data` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tile_store`
--

INSERT INTO `tile_store` (`house_id`, `data`) VALUES
(170, 0x4e0017000701000000871e00),
(170, 0x4d001b000701000000894d00),
(170, 0x4e0018000701000000881e00),
(171, 0x540017000701000000871e00),
(171, 0x520019000701000000804d00),
(171, 0x540018000701000000881e00),
(197, 0xb100470007010000008b1e00),
(197, 0xb100480007010000008c1e00),
(197, 0xb50048000701000000894d00),
(198, 0xa1003d000701000000ac6610a89f370300),
(198, 0xa1003e0007010000007e661048f72b0300),
(198, 0xa5003c000701000000824d00),
(198, 0xa100410007010000008b1e00),
(198, 0xa100420007010000008c1e00),
(198, 0xa200400007010000007e6610b0f1370300),
(199, 0x98003d000701000000a80900),
(199, 0x9a003e0007010000001f1700),
(199, 0x9b003c000701000000824d00),
(199, 0x9b003e000701000000f7160f0100),
(199, 0x9c003e0007010000002e09101072a302110100),
(199, 0x9e0042000701000000731e1497000000157512ec5800),
(199, 0x9e0043000701000000741e1497000000157512ec5800),
(200, 0x93003c000701000000804d00),
(200, 0x9000400007010000008b1e00),
(200, 0x9000410007010000008c1e00),
(202, 0x81003e000701000000804d00),
(202, 0x850040000701000000871e00),
(202, 0x850041000701000000881e00),
(203, 0x76003f000701000000871e00),
(203, 0x760040000701000000881e00),
(203, 0x7a0042000701000000804d00),
(204, 0x770046000701000000804d00),
(204, 0x7a0048000701000000871e00),
(204, 0x7a0049000701000000881e00),
(205, 0x6a0042000701000000894d00),
(205, 0x6b0045000701000000871e00),
(205, 0x6b0046000701000000881e00),
(207, 0x5f0049000701000000871e00),
(207, 0x5f004a000701000000881e00),
(207, 0x5f004b000701000000871e00),
(207, 0x5f004c000701000000881e00),
(207, 0x670047000701000000804d00),
(207, 0x65004d000701000000804d00),
(208, 0x5f0043000701000000804d00),
(208, 0x630041000701000000894d00),
(208, 0x620044000701000000871e00),
(208, 0x620045000701000000881e00),
(209, 0x5f003d000701000000871e00),
(209, 0x5f003e000701000000881e00),
(209, 0x62003d000701000000894d00),
(210, 0xb200340006010000008b1e00),
(210, 0xb200350006010000008c1e00),
(210, 0xb200340007010000008b1e00),
(210, 0xb200350007010000008c1e00),
(210, 0xb00038000701000000804d00),
(211, 0x790080000701000000804d00),
(212, 0x9b006a000701000000804d00),
(213, 0x93003b000601000000804d00),
(213, 0x90003c0006010000008b1e00),
(213, 0x90003d0006010000008c1e00),
(213, 0x930041000601000000804d00),
(215, 0x9c003b000601000000804d00),
(215, 0xa0003c0006010000008b1e00),
(215, 0xa0003d0006010000008c1e00),
(215, 0x9c0041000601000000804d00),
(216, 0xa5003b000601000000804d00),
(216, 0xa8003c0006010000008b1e00),
(216, 0xa8003d0006010000008c1e00),
(216, 0xa50041000601000000804d00),
(217, 0x910031000601000000804d00),
(217, 0x920036000601000000831e00),
(217, 0x920037000601000000841e00),
(218, 0x91002e000601000000804d00),
(218, 0x92002c000601000000831e00),
(218, 0x92002d000601000000841e00),
(225, 0xa20018000601000000871e00),
(225, 0xa20019000601000000881e00),
(225, 0xa4001a000601000000894d00),
(226, 0xa6001c000601000000894d00),
(226, 0xa9001d000601000000871e00),
(226, 0xa9001e000601000000881e00),
(227, 0xa5001f000601000000804d00),
(227, 0xa90021000601000000871e00),
(227, 0xa90022000601000000881e00),
(228, 0xaf001c000601000000831e00),
(228, 0xaf001d000601000000841e00),
(228, 0xb00020000601000000804d00),
(229, 0xb3001b000601000000831e00),
(229, 0xb3001c000601000000841e00),
(229, 0xb50020000601000000804d00),
(230, 0xb8001d000601000000831e00),
(230, 0xb8001e000601000000841e00),
(230, 0xb70021000601000000894d00),
(231, 0xb70024000601000000894d00),
(231, 0xb80025000601000000831e00),
(231, 0xb80026000601000000841e00),
(232, 0xb7002a000601000000894d00),
(232, 0xb8002b000601000000831e00),
(232, 0xb8002c000601000000841e00),
(234, 0x8f0029000501000000831e00),
(234, 0x8f002a000501000000841e00),
(234, 0x91002e000501000000804d00),
(235, 0x8e0032000501000000831e00),
(235, 0x8e0033000501000000841e00),
(235, 0x910033000501000000894d00),
(236, 0x8e0036000501000000831e00),
(236, 0x8e0037000501000000841e00),
(236, 0x920035000501000000804d00),
(237, 0xa5001b000501000000871e00),
(237, 0xa7001a000501000000894d00),
(237, 0xa5001c000501000000881e00),
(238, 0xa8001d000501000000804d00),
(238, 0xa50021000501000000871e00),
(238, 0xa50022000501000000881e00),
(1901, 0x950032000501000000894d00),
(1901, 0x970037000501000000861e00),
(1902, 0x9b0031000501000000804d00),
(1902, 0x9c0037000501000000861e00),
(1903, 0xa10030000501000000804d00),
(1903, 0xa10037000501000000861e00),
(1904, 0xa60032000501000000804d00),
(1904, 0xa60037000501000000861e00),
(1905, 0x9a0029000501000000861e00),
(1905, 0x9a002e000501000000804d00),
(1906, 0x950029000501000000861e00),
(1906, 0x96002e000501000000804d00),
(1908, 0xc6001c0006010000008b1e00),
(1908, 0xc6001d0006010000008c1e00),
(1908, 0xc50024000601000000804d00),
(1909, 0xcd001e0006010000008b1e00),
(1909, 0xcd001f0006010000008c1e00),
(1909, 0xcb0024000601000000804d00),
(1910, 0xd4001c0006010000008b1e00),
(1910, 0xd4001d0006010000008c1e00),
(1910, 0xd00024000601000000804d00),
(1911, 0xda001c0006010000008b1e00),
(1911, 0xda001d0006010000008c1e00),
(1911, 0xd20025000601000000894d00),
(1912, 0xda00270006010000008b1e00),
(1912, 0xd20029000601000000894d00),
(1912, 0xda00280006010000008c1e00),
(1913, 0xda002c0006010000008b1e00),
(1913, 0xda002d0006010000008c1e00),
(1913, 0xd20030000601000000894d00),
(1914, 0xda00330006010000008b1e00),
(1914, 0xd20036000601000000894d00),
(1914, 0xda00340006010000008c1e00),
(1915, 0xda003a0006010000008b1e00),
(1915, 0xda003b0006010000008c1e00),
(1915, 0xd2003c000601000000894d00),
(1916, 0xc7002b0006010000008b1e00),
(1916, 0xc7002c0006010000008c1e00),
(1916, 0xce002c000601000000894d00),
(1917, 0xc700320006010000008b1e00),
(1917, 0xc700330006010000008c1e00),
(1917, 0xce0033000601000000894d00),
(1918, 0x980015000801000000de0600),
(1918, 0x980016000801000000df0600),
(1918, 0x9b0016000801000000361800),
(1919, 0x980019000801000000de0600),
(1919, 0x98001a000801000000df0600),
(1919, 0x9b001a000801000000361800),
(1920, 0x98001d000801000000de0600),
(1920, 0x98001e000801000000df0600),
(1920, 0x9b001e000801000000361800),
(1921, 0x980021000801000000de0600),
(1921, 0x980022000801000000df0600),
(1921, 0x9b0022000801000000361800),
(1922, 0x9f0016000801000000361800),
(1922, 0xa20015000801000000de0600),
(1922, 0xa20016000801000000df0600),
(1923, 0x9f001a000801000000361800),
(1923, 0xa20019000801000000de0600),
(1923, 0xa2001a000801000000df0600),
(1924, 0x9f001e000801000000361800),
(1924, 0xa2001d000801000000de0600),
(1924, 0xa2001e000801000000df0600),
(1925, 0x9f0022000801000000361800),
(1925, 0xa20021000801000000de0600),
(1925, 0xa20022000801000000df0600),
(1926, 0x99001a000901000000de0600),
(1926, 0x99001b000901000000df0600),
(1926, 0x9c001b000901000000361800),
(1927, 0x99001e000901000000de0600),
(1927, 0x99001f000901000000df0600),
(1927, 0x9c001f000901000000361800),
(1928, 0x990022000901000000de0600),
(1928, 0x990023000901000000df0600),
(1928, 0x9c0023000901000000361800),
(1929, 0x990026000901000000de0600),
(1929, 0x990027000901000000df0600),
(1929, 0x9c0027000901000000361800),
(1930, 0xa0001b000901000000361800),
(1930, 0xa3001a000901000000de0600),
(1930, 0xa3001b000901000000df0600),
(1931, 0xa0001f000901000000361800),
(1931, 0xa3001e000901000000de0600),
(1931, 0xa3001f000901000000df0600),
(1932, 0xa00023000901000000361800),
(1932, 0xa30022000901000000de0600),
(1932, 0xa30023000901000000df0600),
(1933, 0xa00027000901000000361800),
(1933, 0xa30026000901000000de0600),
(1933, 0xa30027000901000000df0600),
(1935, 0xae003c000701000000804d00),
(1935, 0xb1003d0007010000008b1e00),
(1935, 0xb1003e0007010000008c1e00),
(1937, 0x950037000601000000861e00),
(1937, 0x970035000601000000894d00),
(1938, 0x99002f000601000000894d00),
(1938, 0x9d002d000601000000831e00),
(1938, 0x9d002e000601000000841e00),
(1939, 0x95002b000601000000861e00),
(1939, 0x97002c000601000000894d00),
(1940, 0x9f002f000601000000831e00),
(1940, 0xa0002f000601000000831e00),
(1940, 0x9f0030000601000000841e00),
(1940, 0xa00030000601000000841e00),
(1940, 0xa10035000601000000804d00),
(1941, 0xa60031000601000000871e00),
(1941, 0xa60032000601000000881e00),
(1941, 0xaa0035000601000000804d00),
(1942, 0x7f003f000601000000831e00),
(1942, 0x84003e000601000000894d00),
(1942, 0x7f0041000501000000831e00),
(1942, 0x7f0042000501000000841e00),
(1942, 0x7f0040000601000000841e00),
(1943, 0x570018000701000000894d00),
(1943, 0x59001a000701000000871e00),
(1943, 0x59001b000701000000881e00),
(1944, 0x57001f000701000000804d00),
(1944, 0x59001d000701000000871e00),
(1944, 0x59001e000701000000881e00),
(1945, 0x69001a0007010000008b1e00),
(1945, 0x69001b0007010000008c1e00),
(1945, 0x680025000701000000804d00),
(1946, 0x76001a000601000000894d00),
(1946, 0x7b0019000601000000de0600),
(1946, 0x7b001a000601000000df0600),
(1946, 0x7c001e000601000000894d00),
(1950, 0x97001a000701000000871e00),
(1950, 0x97001b000701000000881e00),
(1950, 0x94001c000701000000894d00),
(1951, 0x920022000701000000894d00),
(1951, 0x970022000701000000871e00),
(1951, 0x970023000701000000881e00),
(1952, 0x9b0018000701000000871e00),
(1952, 0x9b0019000701000000881e00),
(1952, 0x9d001c000701000000640600),
(1953, 0xa40020000701000000620600),
(1953, 0xa90021000701000000871e00),
(1953, 0xa90022000701000000881e00),
(1954, 0xaf001b000701000000871e00),
(1954, 0xaf001c000701000000881e00),
(1954, 0xb4001f000701000000804d00),
(1955, 0xb7001d000701000000871e00),
(1955, 0xb7001e000701000000881e00),
(1955, 0xb60020000701000000894d00),
(1956, 0xb60026000701000000894d00),
(1956, 0xbd0024000701000000871e00),
(1956, 0xbd0025000701000000881e00),
(1957, 0xb6002a000701000000894d00),
(1957, 0xbd0029000701000000871e00),
(1957, 0xbd002a000701000000881e00),
(1958, 0xbf002c000701000000891e00),
(1958, 0xb90031000701000000894d00),
(1958, 0xc0002c0007010000008a1e00),
(1959, 0xc7002b0007010000008b1e00),
(1959, 0xc7002c0007010000008c1e00),
(1959, 0xc60031000701000000894d00),
(1960, 0xc10012000701000000871e00),
(1960, 0xc10013000701000000881e00),
(1960, 0xc20019000701000000804d00),
(1961, 0xc3001c0007010000008b1e00),
(1961, 0xc3001d0007010000008c1e00),
(1961, 0xc70024000701000000804d00),
(1962, 0xcc001c0007010000008b1e00),
(1962, 0xcc001d0007010000008c1e00),
(1962, 0xd00024000701000000804d00),
(1963, 0xd5001c0007010000008b1e00),
(1963, 0xd5001d0007010000008c1e00),
(1963, 0xd20026000701000000894d00),
(1964, 0xd300280007010000008b1e00),
(1964, 0xd300290007010000008c1e00),
(1964, 0xd2002c000701000000894d00),
(1965, 0xd300320007010000008b1e00),
(1965, 0xd300330007010000008c1e00),
(1965, 0xd20035000701000000894d00),
(1966, 0xd3003a0007010000008b1e00),
(1966, 0xd3003b0007010000008c1e00),
(1966, 0xd2003d000701000000894d00),
(1967, 0xc0003e0007010000008b1e00),
(1967, 0xc0003f0007010000008c1e00),
(1967, 0xba0041000701000000894d00),
(1968, 0x75003b000701000000804d00),
(1969, 0x87001e000701000000894d00),
(1969, 0x8500210007010000008b1e00),
(1969, 0x8500220007010000008c1e00),
(1970, 0x8b00190007010000008b1e00),
(1970, 0x8b001a0007010000008c1e00),
(1970, 0x8c001f000701000000894d00),
(1971, 0x89001b000701000000804d00),
(1972, 0x8500190006010000008b1e00),
(1972, 0x85001a0006010000008c1e00),
(1972, 0x87001f000601000000894d00),
(1973, 0x8500210006010000008b1e00),
(1973, 0x8500220006010000008c1e00),
(1973, 0x8a0020000601000000804d00),
(1974, 0x8e00190006010000008b1e00),
(1974, 0x8e001a0006010000008c1e00),
(1974, 0x8c001d000601000000894d00);

-- --------------------------------------------------------

--
-- Estrutura da tabela `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` text NOT NULL,
  `categoria` int(11) NOT NULL,
  `link` varchar(11) NOT NULL,
  `ativo` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `videos_categorias`
--

CREATE TABLE `videos_categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `videos_comentarios`
--

CREATE TABLE `videos_comentarios` (
  `id` int(11) NOT NULL,
  `mensagem` text NOT NULL,
  `character` varchar(255) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `topico` int(11) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ativo` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_forum`
--

CREATE TABLE `z_forum` (
  `id` int(11) NOT NULL,
  `first_post` int(11) NOT NULL DEFAULT '0',
  `last_post` int(11) NOT NULL DEFAULT '0',
  `section` int(3) NOT NULL DEFAULT '0',
  `replies` int(20) NOT NULL DEFAULT '0',
  `views` int(20) NOT NULL DEFAULT '0',
  `author_aid` int(20) NOT NULL DEFAULT '0',
  `author_guid` int(20) NOT NULL DEFAULT '0',
  `post_text` text NOT NULL,
  `post_topic` varchar(255) NOT NULL,
  `post_smile` tinyint(1) NOT NULL DEFAULT '0',
  `post_date` int(20) NOT NULL DEFAULT '0',
  `last_edit_aid` int(20) NOT NULL DEFAULT '0',
  `edit_date` int(20) NOT NULL DEFAULT '0',
  `post_ip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `icon_id` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_network_box`
--

CREATE TABLE `z_network_box` (
  `id` int(11) NOT NULL,
  `network_name` varchar(10) NOT NULL,
  `network_link` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_news_tickers`
--

CREATE TABLE `z_news_tickers` (
  `date` int(11) NOT NULL DEFAULT '1',
  `author` int(11) NOT NULL,
  `image_id` int(3) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hide_ticker` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `z_news_tickers`
--

INSERT INTO `z_news_tickers` (`date`, `author`, `image_id`, `text`, `hide_ticker`) VALUES
(1445489191, 7944, 0, '<b>W</b>elcome <u>to</u> <b>Otx</b>Server-<b>G</b>lobal [<i>by Malucooo</i>].', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_ots_comunication`
--

CREATE TABLE `z_ots_comunication` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `param1` varchar(255) NOT NULL,
  `param2` varchar(255) NOT NULL,
  `param3` varchar(255) NOT NULL,
  `param4` varchar(255) NOT NULL,
  `param5` varchar(255) NOT NULL,
  `param6` varchar(255) NOT NULL,
  `param7` varchar(255) NOT NULL,
  `delete_it` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_ots_guildcomunication`
--

CREATE TABLE `z_ots_guildcomunication` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `param1` varchar(255) NOT NULL,
  `param2` varchar(255) NOT NULL,
  `param3` varchar(255) NOT NULL,
  `param4` varchar(255) NOT NULL,
  `param5` varchar(255) NOT NULL,
  `param6` varchar(255) NOT NULL,
  `param7` varchar(255) NOT NULL,
  `delete_it` int(2) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_polls`
--

CREATE TABLE `z_polls` (
  `id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `end` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `answers` int(11) NOT NULL,
  `votes_all` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_polls_answers`
--

CREATE TABLE `z_polls_answers` (
  `poll_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `votes` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_shopguild_history_item`
--

CREATE TABLE `z_shopguild_history_item` (
  `id` int(11) NOT NULL,
  `to_name` varchar(255) NOT NULL DEFAULT '0',
  `to_account` int(11) NOT NULL DEFAULT '0',
  `from_nick` varchar(255) NOT NULL,
  `from_account` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `offer_id` int(11) NOT NULL DEFAULT '0',
  `trans_state` varchar(255) NOT NULL,
  `trans_start` int(11) NOT NULL DEFAULT '0',
  `trans_real` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_shopguild_history_pacc`
--

CREATE TABLE `z_shopguild_history_pacc` (
  `id` int(11) NOT NULL,
  `to_name` varchar(255) NOT NULL DEFAULT '0',
  `to_account` int(11) NOT NULL DEFAULT '0',
  `from_nick` varchar(255) NOT NULL,
  `from_account` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `pacc_days` int(11) NOT NULL DEFAULT '0',
  `trans_state` varchar(255) NOT NULL,
  `trans_start` int(11) NOT NULL DEFAULT '0',
  `trans_real` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_shopguild_offer`
--

CREATE TABLE `z_shopguild_offer` (
  `id` int(11) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `itemid1` int(11) NOT NULL DEFAULT '0',
  `count1` int(11) NOT NULL DEFAULT '0',
  `itemid2` int(11) NOT NULL DEFAULT '0',
  `count2` int(11) NOT NULL DEFAULT '0',
  `offer_type` varchar(255) DEFAULT NULL,
  `offer_description` text NOT NULL,
  `offer_name` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `z_shopguild_offer`
--

INSERT INTO `z_shopguild_offer` (`id`, `points`, `itemid1`, `count1`, `itemid2`, `count2`, `offer_type`, `offer_description`, `offer_name`, `pid`) VALUES
(1, 1, 2160, 10, 0, 0, 'item', '10 crystal coin para seu char.', 'Crystal Coin', 0),
(2, 10, 2640, 1, 0, 0, 'item', 'Soft Boots regenerate 10 health per 2 seconds and 15 mana per 2 seconds.', 'Pair of Soft Boots', 0),
(3, 2, 2195, 1, 0, 0, 'item', 'boots of haste (speed +20).', 'Boots of Haste', 0),
(4, 5, 18409, 1, 0, 0, 'item', 'Fire ataque max 85 e magic +1.', 'Wand of Everblazing', 0),
(5, 5, 18411, 1, 0, 0, 'item', 'Earth ataque max 85 e magic +1.', 'Muck Rod', 0),
(6, 5, 2400, 1, 0, 0, 'item', 'Atributos (Atk:48, Def:35 +3).', 'Magic Sword', 0),
(7, 7, 2431, 1, 0, 0, 'item', 'Atributos (Atk:50, Def:30 +3).', 'Stonecutter Axe', 0),
(8, 6, 8928, 1, 0, 0, 'item', 'Atributos (Atk:50, Def:30 +2).', 'Obsidian Truncheon', 0),
(9, 5, 18453, 1, 0, 0, 'item', 'Atributos (Range:6, Atk+4, Hit%+3).', 'Crystal Crossbow', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_shop_history_item`
--

CREATE TABLE `z_shop_history_item` (
  `id` int(11) NOT NULL,
  `to_name` varchar(255) NOT NULL DEFAULT '0',
  `to_account` int(11) NOT NULL DEFAULT '0',
  `from_nick` varchar(255) NOT NULL,
  `from_account` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `offer_id` varchar(255) NOT NULL DEFAULT '',
  `trans_state` varchar(255) NOT NULL,
  `trans_start` int(11) NOT NULL DEFAULT '0',
  `trans_real` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `z_shop_offer`
--

CREATE TABLE `z_shop_offer` (
  `id` int(11) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `itemid1` int(11) NOT NULL DEFAULT '0',
  `count1` int(11) NOT NULL DEFAULT '0',
  `itemid2` int(11) NOT NULL DEFAULT '0',
  `count2` int(11) NOT NULL DEFAULT '0',
  `offer_type` varchar(255) DEFAULT NULL,
  `offer_description` text NOT NULL,
  `offer_name` varchar(255) NOT NULL,
  `offer_category` int(11) NOT NULL,
  `offer_new` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `z_shop_offer`
--

INSERT INTO `z_shop_offer` (`id`, `points`, `itemid1`, `count1`, `itemid2`, `count2`, `offer_type`, `offer_description`, `offer_name`, `offer_category`, `offer_new`, `pid`) VALUES
(234, 20, 2358, 1, 0, 0, 'itemvip', 'Faster regeneration', 'Fury Boots', 1, 0, 0),
(235, 11, 12544, 1, 0, 0, 'itemvip', 'refill stamina 100% (1 charge).', 'Refill Stamina', 1, 0, 0),
(236, 30, 16101, 1, 0, 0, 'itemvip', 'Using this item will add 30 Tibia Coins to your account once.', 'Tibia Coins', 1, 0, 0),
(237, 8, 13030, 1, 0, 0, 'itemvip', 'Change your sex!', 'Change sex doll', 1, 0, 0),
(238, 5, 11144, 1, 0, 0, 'itemvip', 'Use it to remove your black or red skull.', 'Remover Skull', 1, 0, 0),
(239, 7, 18403, 1, 0, 0, 'item', 'you see a prismatic helmet (Arm:9, shielding +1, protection physical +5%). It can only be wielded properly by knights of level 150 or higher.', 'Prismatic Helmet', 2, 0, 0),
(240, 7, 18404, 1, 0, 0, 'item', 'You see a prismatic armor (Arm:15, protection physical +5%, speed +15). It can only be wielded properly by knights and paladins of level 120 or higher.', 'Prismatic Armor', 2, 0, 0),
(241, 7, 18405, 1, 0, 0, 'item', 'You see prismatic legs (Arm:8, distance fighting +2, protection physical +3%). It can only be wielded properly by paladins of level 150 or higher.', 'Prismatic Legs', 2, 0, 0),
(242, 7, 18406, 1, 0, 0, 'item', 'You see prismatic boots (Arm:3, protection death +3%, speed +15). It can only be wielded properly by paladins of level 150 or higher.', 'Prismatic Boots', 2, 0, 0),
(243, 7, 18410, 1, 0, 0, 'item', 'You see a prismatic shield (Def:37, shielding +2, protection physical +4%). It can only be wielded properly by knights of level 150 or higher.', 'Prismatic Shield', 2, 0, 0),
(244, 5, 8851, 1, 0, 0, 'item', 'You see a royal crossbow (Range:6, Atk+5, Hit%+3). It can only be wielded properly by paladins of level 130 or higher. It weighs 120.00 oz.', 'Royal Crossbow', 2, 0, 0),
(245, 8, 16112, 1, 0, 0, 'item', 'You see a spellbook of ancient arcana (Def:19, magic level +4, protection death +5%). It can only be wielded properly by sorcerers and druids of level 150 or higher. It weighs 25.00 oz. It shows your spells and can also shield against attacks when worn.', 'Spellbook of Ancient Arcana', 2, 0, 0),
(246, 10, 12647, 1, 0, 0, 'item', 'You see a snake god\'s wristguard (Def:14, magic level +3). It can only be wielded properly by sorcerers and druids of level 100 or higher. It weighs 28.00 oz. It shows your spells and can also shield against attacks when worn.', 'Snake God\'s Wristguard', 2, 0, 0),
(247, 5, 9778, 1, 0, 0, 'item', 'You see a yalahari mask (Arm:5, magic level +2). It can only be wielded properly by sorcerers and druids of level 80 or higher. It weighs 35.00 oz.', 'Yalahari Mask', 2, 0, 0),
(248, 5, 9776, 1, 0, 0, 'item', 'You see a yalahari armor (Arm:16, protection death +3%). It can only be wielded properly by knights of level 80 or higher. It weighs 70.00 oz.', 'Yalahari Armor', 2, 0, 0),
(249, 5, 9776, 1, 0, 0, 'item', 'You see a yalahari leg piece (Arm:8, distance fighting +2, protection death +5%). It can only be wielded properly by paladins of level 80 or higher. It weighs 65.00 oz.', 'Yalahari leg piece', 2, 0, 0),
(250, 6, 12645, 1, 0, 0, 'item', 'You see an elite draken helmet (Arm:9, distance fighting +1, protection death +3%). It can only be wielded properly by paladins of level 100 or higher. It weighs 43.00 oz.', 'Elite draken helmet', 2, 0, 0),
(251, 5, 12642, 1, 0, 0, 'item', 'You see a royal draken mail (Arm:16, shielding +3, protection physical +5%). It can only be wielded properly by knights of level 100 or higher. It weighs 130.00 oz.', 'Royal draken mail', 2, 0, 0),
(252, 7, 12643, 1, 0, 0, 'item', 'You see a royal scale robe (Arm:12, magic level +2, protection fire +5%). It can only be wielded properly by sorcerers and druids of level 100 or higher. It weighs 45.00 oz.', 'royal scale robe', 2, 0, 0),
(253, 6, 8889, 1, 0, 0, 'item', 'You see a skullcracker armor (Arm:14, protection holy -5%, death +5%). It can only be wielded properly by knights of level 100 or higher.', 'Skullcracker Armor', 2, 0, 0),
(254, 8, 8881, 1, 0, 0, 'item', 'You see a fireborn giant armor (Arm:15, sword fighting +2, protection fire +5%, ice -5%). It can only be wielded properly by knights of level 100 or higher. It weighs 120.00 oz.', 'Fireborn giant armo', 2, 0, 0),
(255, 8, 8883, 1, 0, 0, 'item', 'You see a windborn colossus armor (Arm:15, club fighting +2, protection energy +5%, earth -5%). It can only be wielded properly by knights of level 100 or higher. It weighs 120.00 oz.', 'Windborn colossus armor', 2, 0, 0),
(256, 8, 8882, 1, 0, 0, 'itemvip', 'You see an earthborn titan armor (Arm:15, axe fighting +2, protection earth +5%, fire -5%). It can only be wielded properly by knights of level 100 or higher. It weighs 120.00 oz.', 'Earthborn titan armor', 2, 0, 0),
(257, 10, 21725, 1, 0, 0, 'item', 'Furious frock (10 points)\r\nYou see a furious frock (Arm:12, magic level +2, protection fire +5%). It can only be wielded properly by sorcerers and druids of level 130 or higher. It weighs 34.00 oz.', 'Furious frock', 2, 0, 0),
(258, 10, 15407, 1, 0, 0, 'item', 'You see a depth lorica (Arm:16, distance fighting +3, protection death +5%). It can only be wielded properly by paladins of level 150 or higher. It weighs 145.00 oz.', 'Depth lorica', 2, 0, 0),
(259, 10, 15406, 1, 0, 0, 'item', 'You see an ornate chestplate (Arm:16, shielding +3, protection physical +8%). It can only be wielded properly by knights of level 200 or higher. It weighs 156.00 oz.', 'Ornate chestplate', 2, 0, 0),
(260, 10, 15412, 1, 0, 0, 'item', 'You see an ornate legs (Arm:8, protection physical +5%). It can only be wielded properly by knights of level 185 or higher. It weighs 77.00 oz.', 'Ornate legs', 2, 0, 0),
(261, 9, 2504, 1, 0, 0, 'item', 'Arm:7, protection physical +3%', 'Dwarven legs', 2, 0, 0),
(262, 5, 15413, 1, 0, 0, 'item', 'You see an ornate shield (Def:36, protection physical +5%). It can only be wielded properly by knights of level 130 or higher. It weighs 71.00 oz.', 'Ornate shield', 2, 0, 0),
(263, 7, 18423, 10, 0, 0, 'item', '10x major crystalline token.', 'Major crystalline token', 2, 0, 0),
(264, 5, 18422, 10, 0, 0, 'item', '10x minor crystalline token.', 'Minor crystalline token', 2, 0, 0),
(265, 7, 6433, 1, 0, 0, 'item', 'Def: 37', 'Necromancer shield', 2, 0, 0),
(266, 7, 6391, 1, 0, 0, 'item', 'Def: 37', 'Nightmare shield', 2, 0, 0),
(267, 10, 15408, 1, 0, 0, 'item', 'You see a depth galea (Arm:8, protection drown +100%). It can only be wielded properly by players of level 150 or higher. It weighs 46.00 oz. Enables underwater exploration.', 'Depth galea', 2, 0, 0),
(268, 5, 20620, 1, 0, 0, 'item', 'You see a Zaoan chess box (Vol:32). It weighs 38.00 oz. This chess box is made of jade and obsidian. It will hold a full set of 32 Zaoan chess figures.', 'Zaoan chess box', 2, 0, 0),
(269, 5, 18452, 1, 0, 0, 'item', 'You see a mycological mace (Atk:50, Def:31 +3, club fighting +1). It can only be wielded properly by players of level 120 or higher. It weighs 59.00 oz.', 'Mycological Mace', 2, 0, 0),
(270, 5, 18451, 1, 0, 0, 'item', 'You see a crystalline axe (Atk:51, Def:29 +3, axe fighting +1). It can only be wielded properly by players of level 120 or higher. It weighs 76.00 oz. Even in the light of day, the stars seem to reflect in each facet of this crystalline axe.', 'Crystalline Axe', 2, 0, 0),
(271, 5, 18465, 1, 0, 0, 'item', 'You see a shiny blade (Atk:50, Def:35 +3, sword fighting +1). It can only be wielded properly by players of level 120 or higher. It weighs 45.00 oz.', 'Shiny Blade', 2, 0, 0),
(272, 8, 21700, 1, 0, 0, 'item', '(Arm:8, protection ice +16%)', 'Icy culottes', 2, 0, 0),
(273, 20, 28423, 1, 0, 0, 'item', 'Voce recebera o addon male e female full no jogo.', 'Barbarian', 3, 0, 0),
(274, 20, 28423, 1, 0, 0, 'addon', 'Voce recebera o addon male e female full no jogo.', 'Barbarian', 4, 0, 0),
(275, 20, 28422, 1, 0, 0, 'addon', 'test', 'test', 3, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `name_2` (`name`),
  ADD UNIQUE KEY `name_3` (`name`);

--
-- Indexes for table `account_bans`
--
ALTER TABLE `account_bans`
  ADD PRIMARY KEY (`account_id`),
  ADD KEY `banned_by` (`banned_by`);

--
-- Indexes for table `account_ban_history`
--
ALTER TABLE `account_ban_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `banned_by` (`banned_by`),
  ADD KEY `account_id_2` (`account_id`),
  ADD KEY `account_id_3` (`account_id`),
  ADD KEY `account_id_4` (`account_id`),
  ADD KEY `account_id_5` (`account_id`);

--
-- Indexes for table `account_viplist`
--
ALTER TABLE `account_viplist`
  ADD UNIQUE KEY `account_player_index` (`account_id`,`player_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `global_storage`
--
ALTER TABLE `global_storage`
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `guilds`
--
ALTER TABLE `guilds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `ownerid` (`ownerid`);

--
-- Indexes for table `guildwar_kills`
--
ALTER TABLE `guildwar_kills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warid` (`warid`);

--
-- Indexes for table `guild_invites`
--
ALTER TABLE `guild_invites`
  ADD PRIMARY KEY (`player_id`,`guild_id`),
  ADD KEY `guild_id` (`guild_id`);

--
-- Indexes for table `guild_membership`
--
ALTER TABLE `guild_membership`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `guild_id` (`guild_id`),
  ADD KEY `rank_id` (`rank_id`);

--
-- Indexes for table `guild_ranks`
--
ALTER TABLE `guild_ranks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guild_id` (`guild_id`);

--
-- Indexes for table `guild_wars`
--
ALTER TABLE `guild_wars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guild1` (`guild1`),
  ADD KEY `guild2` (`guild2`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `owner` (`owner`),
  ADD KEY `town_id` (`town_id`);

--
-- Indexes for table `house_lists`
--
ALTER TABLE `house_lists`
  ADD KEY `house_id` (`house_id`);

--
-- Indexes for table `ip_bans`
--
ALTER TABLE `ip_bans`
  ADD PRIMARY KEY (`ip`),
  ADD KEY `banned_by` (`banned_by`);

--
-- Indexes for table `live_casts`
--
ALTER TABLE `live_casts`
  ADD UNIQUE KEY `player_id_2` (`player_id`);

--
-- Indexes for table `market_history`
--
ALTER TABLE `market_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `player_id` (`player_id`,`sale`);

--
-- Indexes for table `market_offers`
--
ALTER TABLE `market_offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale` (`sale`,`itemtype`),
  ADD KEY `created` (`created`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `vocation` (`vocation`);

--
-- Indexes for table `players_online`
--
ALTER TABLE `players_online`
  ADD PRIMARY KEY (`player_id`);

--
-- Indexes for table `player_deaths`
--
ALTER TABLE `player_deaths`
  ADD KEY `player_id` (`player_id`),
  ADD KEY `killed_by` (`killed_by`),
  ADD KEY `mostdamage_by` (`mostdamage_by`);

--
-- Indexes for table `player_depotitems`
--
ALTER TABLE `player_depotitems`
  ADD UNIQUE KEY `player_id_2` (`player_id`,`sid`);

--
-- Indexes for table `player_inboxitems`
--
ALTER TABLE `player_inboxitems`
  ADD UNIQUE KEY `player_id_2` (`player_id`,`sid`);

--
-- Indexes for table `player_items`
--
ALTER TABLE `player_items`
  ADD KEY `player_id` (`player_id`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `player_killers`
--
ALTER TABLE `player_killers`
  ADD KEY `kill_id` (`kill_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `player_kills`
--
ALTER TABLE `player_kills`
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `player_namelocks`
--
ALTER TABLE `player_namelocks`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `namelocked_by` (`namelocked_by`);

--
-- Indexes for table `player_rewards`
--
ALTER TABLE `player_rewards`
  ADD UNIQUE KEY `player_id_2` (`player_id`,`sid`);

--
-- Indexes for table `player_spells`
--
ALTER TABLE `player_spells`
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `player_storage`
--
ALTER TABLE `player_storage`
  ADD PRIMARY KEY (`player_id`,`key`);

--
-- Indexes for table `sellchar`
--
ALTER TABLE `sellchar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `server_config`
--
ALTER TABLE `server_config`
  ADD PRIMARY KEY (`config`);

--
-- Indexes for table `store_history`
--
ALTER TABLE `store_history`
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `tile_store`
--
ALTER TABLE `tile_store`
  ADD KEY `house_id` (`house_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos_categorias`
--
ALTER TABLE `videos_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos_comentarios`
--
ALTER TABLE `videos_comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_forum`
--
ALTER TABLE `z_forum`
  ADD PRIMARY KEY (`id`),
  ADD KEY `section` (`section`);

--
-- Indexes for table `z_network_box`
--
ALTER TABLE `z_network_box`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_ots_comunication`
--
ALTER TABLE `z_ots_comunication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_ots_guildcomunication`
--
ALTER TABLE `z_ots_guildcomunication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_polls`
--
ALTER TABLE `z_polls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_shopguild_history_item`
--
ALTER TABLE `z_shopguild_history_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_shopguild_history_pacc`
--
ALTER TABLE `z_shopguild_history_pacc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_shopguild_offer`
--
ALTER TABLE `z_shopguild_offer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_shop_history_item`
--
ALTER TABLE `z_shop_history_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_shop_offer`
--
ALTER TABLE `z_shop_offer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `account_ban_history`
--
ALTER TABLE `account_ban_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guilds`
--
ALTER TABLE `guilds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guildwar_kills`
--
ALTER TABLE `guildwar_kills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guild_ranks`
--
ALTER TABLE `guild_ranks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guild_wars`
--
ALTER TABLE `guild_wars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1975;
--
-- AUTO_INCREMENT for table `market_history`
--
ALTER TABLE `market_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `market_offers`
--
ALTER TABLE `market_offers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT for table `sellchar`
--
ALTER TABLE `sellchar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `videos_categorias`
--
ALTER TABLE `videos_categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `videos_comentarios`
--
ALTER TABLE `videos_comentarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_forum`
--
ALTER TABLE `z_forum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_network_box`
--
ALTER TABLE `z_network_box`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `z_ots_comunication`
--
ALTER TABLE `z_ots_comunication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_ots_guildcomunication`
--
ALTER TABLE `z_ots_guildcomunication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13382;
--
-- AUTO_INCREMENT for table `z_polls`
--
ALTER TABLE `z_polls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_shopguild_history_item`
--
ALTER TABLE `z_shopguild_history_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_shopguild_history_pacc`
--
ALTER TABLE `z_shopguild_history_pacc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_shopguild_offer`
--
ALTER TABLE `z_shopguild_offer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `z_shop_history_item`
--
ALTER TABLE `z_shop_history_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_shop_offer`
--
ALTER TABLE `z_shop_offer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=276;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `account_bans`
--
ALTER TABLE `account_bans`
  ADD CONSTRAINT `account_bans_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `account_bans_ibfk_2` FOREIGN KEY (`banned_by`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `account_ban_history`
--
ALTER TABLE `account_ban_history`
  ADD CONSTRAINT `account_ban_history_ibfk_2` FOREIGN KEY (`banned_by`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `account_ban_history_ibfk_3` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `account_ban_history_ibfk_4` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `account_ban_history_ibfk_5` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `account_ban_history_ibfk_6` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `account_viplist`
--
ALTER TABLE `account_viplist`
  ADD CONSTRAINT `account_viplist_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `account_viplist_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `guilds`
--
ALTER TABLE `guilds`
  ADD CONSTRAINT `guilds_ibfk_1` FOREIGN KEY (`ownerid`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `guildwar_kills`
--
ALTER TABLE `guildwar_kills`
  ADD CONSTRAINT `guildwar_kills_ibfk_1` FOREIGN KEY (`warid`) REFERENCES `guild_wars` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `guild_invites`
--
ALTER TABLE `guild_invites`
  ADD CONSTRAINT `guild_invites_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `guild_invites_ibfk_2` FOREIGN KEY (`guild_id`) REFERENCES `guilds` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `guild_membership`
--
ALTER TABLE `guild_membership`
  ADD CONSTRAINT `guild_membership_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guild_membership_ibfk_2` FOREIGN KEY (`guild_id`) REFERENCES `guilds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guild_membership_ibfk_3` FOREIGN KEY (`rank_id`) REFERENCES `guild_ranks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `guild_ranks`
--
ALTER TABLE `guild_ranks`
  ADD CONSTRAINT `guild_ranks_ibfk_1` FOREIGN KEY (`guild_id`) REFERENCES `guilds` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `house_lists`
--
ALTER TABLE `house_lists`
  ADD CONSTRAINT `house_lists_ibfk_1` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `ip_bans`
--
ALTER TABLE `ip_bans`
  ADD CONSTRAINT `ip_bans_ibfk_1` FOREIGN KEY (`banned_by`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `live_casts`
--
ALTER TABLE `live_casts`
  ADD CONSTRAINT `live_casts_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `market_history`
--
ALTER TABLE `market_history`
  ADD CONSTRAINT `market_history_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `market_offers`
--
ALTER TABLE `market_offers`
  ADD CONSTRAINT `market_offers_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `players`
--
ALTER TABLE `players`
  ADD CONSTRAINT `players_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_deaths`
--
ALTER TABLE `player_deaths`
  ADD CONSTRAINT `player_deaths_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_depotitems`
--
ALTER TABLE `player_depotitems`
  ADD CONSTRAINT `player_depotitems_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_inboxitems`
--
ALTER TABLE `player_inboxitems`
  ADD CONSTRAINT `player_inboxitems_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_items`
--
ALTER TABLE `player_items`
  ADD CONSTRAINT `player_items_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_namelocks`
--
ALTER TABLE `player_namelocks`
  ADD CONSTRAINT `player_namelocks_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `player_namelocks_ibfk_2` FOREIGN KEY (`namelocked_by`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `player_rewards`
--
ALTER TABLE `player_rewards`
  ADD CONSTRAINT `player_rewards_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_spells`
--
ALTER TABLE `player_spells`
  ADD CONSTRAINT `player_spells_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `player_storage`
--
ALTER TABLE `player_storage`
  ADD CONSTRAINT `player_storage_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `store_history`
--
ALTER TABLE `store_history`
  ADD CONSTRAINT `store_history_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `tile_store`
--
ALTER TABLE `tile_store`
  ADD CONSTRAINT `tile_store_ibfk_1` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
