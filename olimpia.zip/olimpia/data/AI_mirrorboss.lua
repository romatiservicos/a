CREATURE_SAVE = {}
SUMMON_SAVE = {}
CREATURE_BEHAVIOR = {}
saveId = 1
 
-- Behavior functions ALWAYS have configid and monster as first parameters.
function doSplit(configid, monster, summon, amount, radiusx, radiusy)
    if monster and monster:isMonster() then
        local pos = monster:getPosition()
        local sumcount = 0
        for i = 1, amount do
            local monster = Game.createMonster(summon, Position(math.random(pos.x-radiusx, pos.x+radiusx), math.random(pos.y-radiusy, pos.y+radiusy), pos.z), true, true)
            if monster then
                monster:registerEvent("SummonDeath")
                SUMMON_SAVE[monster:getId()] = saveId
                sumcount = sumcount + 1
            end
        end
        CREATURE_BEHAVIOR[monster:getId()] = nil
        CREATURE_SAVE[saveId] = {configid, monster:getName(), monster:getHealth(), pos, sumcount}
        saveId = saveId+1
        monster:remove()
    end
end
 
function fullHeal(configid, monster)
    if monster and monster:isMonster() then
        monster:addHealth(monster:getMaxHealth()-monster:getHealth())
        CREATURE_BEHAVIOR[monster:getId()] = configid+1
    end
end