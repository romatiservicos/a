function onUse(cid, item, topos)
        local doors = {
                [8651] = {vocation = {1, 5}, messageFail = "Sorry, you need to be a Sorcerer or Master Sorcerer to pass."},
                [8652] = {vocation = {2, 6}, messageFail = "Sorry, you need to be a Druid or Elder Druid to pass."},
                [8653] = {vocation = {3, 7}, messageFail = "Sorry, you need to be a Paladin or Royal Paladin to pass."},
                [8654] = {vocation = {4, 8}, messageFail = "Sorry, you need to be a Knight or Elite Knight to pass."},
        }
 
        if not(isInArray(doors[item.actionid].vocation, getPlayerVocation(cid))) then
                return doPlayerSendCancel(cid, doors[item.actionid].messageFail)
        end
 
        doTeleportThing(cid, topos, TRUE)
        return true
end