function onUse(cid, item, frompos, item2, topos)


if item.uid == 3005 then
queststatus = getPlayerStorageValue(cid,3005)
if queststatus == -1 then

reqlevel = 8
level = getPlayerLevel(cid)

if level >= reqlevel then
doPlayerSendTextMessage(cid,22,"You have found Citizen Addons.")
doPlayerAddOutfit(cid,128,1)
doPlayerAddOutfit(cid,128,2)
doPlayerAddOutfit(cid,136,1)
doPlayerAddOutfit(cid,136,2)
doSendMagicEffect(topos,12)
setPlayerStorageValue(cid,3005,1)
else
doPlayerSendTextMessage(cid, 22, "You need "..reqlevel..". to get this addons.")
end
else
doPlayerSendTextMessage(cid, 22, "You already have this addons.")

end


else
return 0
end

return 1
end