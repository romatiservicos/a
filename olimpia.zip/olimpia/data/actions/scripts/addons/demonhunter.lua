function onUse(cid, item, frompos, item2, topos)


if item.uid == 3095 then
queststatus = getPlayerStorageValue(cid,3095)
if queststatus == -1 then

reqlevel = 8
level = getPlayerLevel(cid)

if level >= reqlevel then
doPlayerSendTextMessage(cid,22,"You have found Demonhunter Addons.")
doPlayerAddOutfit(cid,288,1)
doPlayerAddOutfit(cid,288,2)
doPlayerAddOutfit(cid,289,1)
doPlayerAddOutfit(cid,289,2)
doSendMagicEffect(topos,12)
setPlayerStorageValue(cid,3095,1)
else
doPlayerSendTextMessage(cid, 22, "You need "..reqlevel..". to get this addons.")
end
else
doPlayerSendTextMessage(cid, 22, "You already have this addons.")

end


else
return 0
end

return 1
end