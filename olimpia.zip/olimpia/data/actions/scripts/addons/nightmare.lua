function onUse(cid, item, frompos, item2, topos)


if item.uid == 3080 then
queststatus = getPlayerStorageValue(cid,3080)
if queststatus == -1 then

reqlevel = 8
level = getPlayerLevel(cid)

if level >= reqlevel then
doPlayerSendTextMessage(cid,22,"You have found Nightmare Addons.")
doPlayerAddOutfit(cid,269,1)
doPlayerAddOutfit(cid,269,2)
doPlayerAddOutfit(cid,268,1)
doPlayerAddOutfit(cid,268,2)
doSendMagicEffect(topos,12)
setPlayerStorageValue(cid,3080,1)
else
doPlayerSendTextMessage(cid, 22, "You need "..reqlevel..". to get this addons.")
end
else
doPlayerSendTextMessage(cid, 22, "You already have this addons.")

end


else
return 0
end

return 1
end