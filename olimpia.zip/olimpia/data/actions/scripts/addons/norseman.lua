function onUse(cid, item, frompos, item2, topos)


if item.uid == 3075 then
queststatus = getPlayerStorageValue(cid,3075)
if queststatus == -1 then

reqlevel = 8
level = getPlayerLevel(cid)

if level >= reqlevel then
doPlayerSendTextMessage(cid,22,"You have found Norseman Addons.")
doPlayerAddOutfit(cid,252,1)
doPlayerAddOutfit(cid,252,2)
doPlayerAddOutfit(cid,251,1)
doPlayerAddOutfit(cid,251,2)
doSendMagicEffect(topos,12)
setPlayerStorageValue(cid,3075,1)
else
doPlayerSendTextMessage(cid, 22, "You need "..reqlevel..". to get this addons.")
end
else
doPlayerSendTextMessage(cid, 22, "You already have this addons.")

end


else
return 0
end

return 1
end