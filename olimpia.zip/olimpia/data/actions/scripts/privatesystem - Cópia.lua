local item = 18423

local level = 8

function onUse(cid, item, frompos, item2, topos)

        local player = Player(cid)

    if player:getStorageValue(58344) >= os.time() then

        player:say('Voce ja esta com acesso liberado a Mirror Private Cave.', TALKTYPE_MONSTER_SAY)

        return true

    end

    

        player:setStorageValue(58344, os.time() + 60)

    Item(item.uid):remove(1)

    player:say('Você ganhou 1 minutos de Exclusive hunt!', TALKTYPE_MONSTER_SAY)

    

    if item.itemid == scroll and getPlayerLevel(cid) >= level then

        doTeleportThing(cid, temple, TRUE)

        doSendMagicEffect(temple,10)

    else

    end


return 1

end