function onUse(cid, item, frompos, item2, topos)
    local player = Player(cid)
	local config = {
	timeExhausted = 0.01, -- tempo em horas para poder usar o item novamente.
	timeForUse = 0.2, -- tempo em horas que o player poderá entrar na cave.
	exhausted = 456789,
	storage = 789456,
	toKnow = 123456,
	pos = {x = 159, y = 49, z = 7},
	effect = 27 -- efeito que dará ao usar o item.
	}

if getPlayerStorageValue(cid, config.exhausted) < os.time() then
		setPlayerStorageValue (cid, config.storage, config.timeForUse * 60 * 60 + os.time())
		setPlayerStorageValue (cid, config.exhausted, config.timeExhausted * 60 * 60 + os.time())
		setPlayerStorageValue (cid, config.toKnow, 1)
		doSendMagicEffect (getThingPos(cid), config.effect)
		doPlayerRemoveItem(cid, 18423, 1)
		doPlayerSendTextMessage (cid, 19, "Voce liberou o acesso a private mirror hunt.")
	else
		doPlayerSendTextMessage (cid, 19, "Voce precisa esperar horas para utilizar novamente!")
	end
return true
end