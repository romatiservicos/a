local vocations = {
    -- Vocation id 1 gonna upgrade to vocation id 2
    -- Easy, huh?
    [5] = 9,
    [6] = 10,
    [7] = 11,
    [8] = 12,
}
 
function onUse(cid, item, fromPosition, itemEX, toPosition)
local player = Player(cid)
local vocation = player:getVocation()
local vocID = vocation:getId()
local vocationName = vocation:getName()
        if vocations[vocID] then
            player:sendTextMessage(MESSAGE_STATUS_CONSOLE_BLUE, 'Voce avancou com sucesso de '..vocationName..' para '..Vocation(vocations[vocID]):getName()..'. ')
            player:setVocation(Vocation(vocations[vocID]))
            Item(item.uid):remove()
        else
            player:sendTextMessage(MESSAGE_STATUS_CONSOLE_BLUE, 'Voce nao pode melhorar a promotion.')
        end
   return true
end