local config = {
percent = 0.5, --- porcentagem do dano que irá levar (0.5 = 50%)
storageskill = 19501, -- storage da skill
itemplace = 5, -- lugar q ela deve estar (8 é o feet)
itemid = 2521, -- id do item 
damagemin = 1000 --- minimo de dano que deve ser pro player absorver 
}


function onStatsChange(cid, attacker, type, combat, value)
if type == STATSCHANGE_HEALTHLOSS and isCreature(attacker) and value >= config.damagemin then
if getPlayerSlotItem(cid, config.itemplace).itemid == config.itemid then
if getPlayerStorageValue(cid, config.storageskill) >= 1 then
value = math.ceil(value*(config.percent))
setPlayerStorageValue(cid, config.storageskill, getPlayerStorageValue(cid, config.storageskill)-1) 
doTargetCombatHealth(attacker, cid, combat, -value, -value, 255)
doPlayerSendTextMessage(cid, 23, "Seu "..getItemNameById(config.itemid).." Absorveu "..value.." do ultimo hit recebido.")  
return false
end
end
end
return true
end