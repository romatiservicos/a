function onLogin(cid)
	aurastr = 25950 -- storage da aura
	setPlayerStorageValue(cid, aurastr, -1)
	return TRUE
end