-- summon heal master v1.1
-- by leyendario.
    local config = {
    heal = 1000,
    mana = 1000, -- put 0 if you dont want him to recover mana.
    condition = "yes", -- put no if you dont want him to remove the conditions (fire, poison, etc).
    }
 
function onCast(cid, target)
 
    local master = getCreatureMaster(cid)
    if master then
        local conditions = {CONDITION_POISON, CONDITION_FIRE, CONDITION_ENERGY, CONDITION_PARALYZE, CONDITION_DRUNK, CONDITION_DROWN, CONDITION_CURSED}
        local party = getPartyMembers(master)
        local pos = getCreaturePosition(master)
        if not getPlayerParty(master) then
            doCreatureAddHealth(master, config.heal)
            doCreatureAddMana(master, config.mana)
            doSendMagicEffect(pos, 12)
            if (config.condition == "yes") then
                for i, todos in ipairs(conditions) do
                    doRemoveCondition(master, todos)
                end
            end
            return true
        end
        for _, miembros in pairs(party) do
            doCreatureAddMana(miembros, config.mana)
            doCreatureAddHealth(miembros, config.heal)
            pos = getCreaturePosition(miembros)
            doSendMagicEffect(pos, 12)
            if (config.contidion == "yes") then
                for i, todos in ipairs(conditions) do
                    doRemoveCondition(miembros, todos)
                end
            end
        end
    end
    return true
end