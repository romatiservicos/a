if getCreatureName(target) == "Mirror" then
doTeleportThing(cid, getThingPos(target))
end