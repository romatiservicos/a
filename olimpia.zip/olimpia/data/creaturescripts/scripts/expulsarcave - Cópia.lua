local config = {
toKnow = 123456,
storage = 789456,
cooldown = 0.6,
pos = {x = 159, y = 49, z = 7}, -- para onde o jogador será teleportado caso o tempo tenha acabado.
}

function onThink(cid, interval)
    print(1)
    if getPlayerStorageValue (cid, config.toKnow) == 1 then
	print(2)
	if getPlayerStorageValue (cid, config.storage) < os.time () then
	print(3)
	addEvent(function()
    if isCreature(cid) then
      doTeleportThing (cid, {x = 159, y = 49, z = 7})
    end
    end, 15 * 60) -- ativa depois de 15 segundos.
	print(4)
	setPlayerStorageValue (cid, config.toKnow, 0)
    player:sendTextMessage(TALKTYPE_ORANGE_1, "Seu tempo de hunt chegou ao fim!")
    end
	end 
 return true
end
 
--function Templo(cid)
 --   local player = Player(cid)
  --  if not player then
   --     return
   -- end
   -- player:teleportTo(config.pos)
 
--end

function onKill(cid, target, lastHit)
	if getPlayerStorageValue (cid, config.toKnow) == 1 then
		if getPlayerStorageValue (cid, config.storage) < os.time () then
			doTeleportThing (cid, config.pos)
			setPlayerStorageValue (cid, config.toKnow, 0)
			doPlayerSendTextMessage (cid, 19, "Seu tempo de hunt chegou ao fim!")
		end
	end
return true
end

function onLogin(cid)
	if getPlayerStorageValue (cid, config.toKnow) == 1 then
		if getPlayerStorageValue (cid, config.storage)  < os.time () then
			doTeleportThing (cid, config.pos)
			setPlayerStorageValue (cid, config.toKnow, 0)
			doPlayerSendTextMessage (cid, 19, "Seu tempo de hunt chegou ao fim!")
		end
	end
return true
end