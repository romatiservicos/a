local function onMovementRemoveProtection(cid, oldPosition, time)
	local player = Player(cid)
	if not player then
		return true
	end

	local playerPosition = player:getPosition()
	if (playerPosition.x ~= oldPosition.x or playerPosition.y ~= oldPosition.y or playerPosition.z ~= oldPosition.z) or player:getTarget() then
		player:setStorageValue(Storage.combatProtectionStorage, 0)
		return true
	end

	addEvent(onMovementRemoveProtection, 1000, cid, oldPosition, time - 1)
end

function onLogin(player)

    player:loadVipData()
    player:updateVipTime()

	
	local loginStr = "Bem vindo ao " .. configManager.getString(configKeys.SERVER_NAME) .. "!"
	if player:getLastLoginSaved() <= 0 then
		loginStr = loginStr .. " Por favor, escolha seu outfit."
		player:sendOutfitWindow()
	else
		if loginStr ~= "" then
			player:sendTextMessage(MESSAGE_STATUS_DEFAULT, loginStr)
		end

		loginStr = string.format("Sua ultima visita ao server foi em %s.", os.date("%a %b %d %X %Y", player:getLastLoginSaved()))
	end
	player:sendTextMessage(MESSAGE_STATUS_DEFAULT, loginStr)
	player:sendTextMessage(MESSAGE_STATUS_CONSOLE_ORANGE, 'Bem vindo ao Test Server do Baiak Mirror.')
    player:sendTextMessage(MESSAGE_STATUS_CONSOLE_ORANGE, 'Qualquer bug reporte a staff usando o canal help, caso confirmado o bug, voce sera recompensado.')
    player:sendTextMessage(MESSAGE_STATUS_CONSOLE_ORANGE, 'Confira nossos sistemas exclusivos.')

	local playerId = player:getId()

	-- Stamina
	nextUseStaminaTime[player.uid] = 0

	-- Promotion
	local vocation = player:getVocation()
	local promotion = vocation:getPromotion()
	if player:isPremium() then
		local value = player:getStorageValue(STORAGEVALUE_PROMOTION)
		if not promotion and value ~= 1 then
			player:setStorageValue(STORAGEVALUE_PROMOTION, 1)
		elseif value == 1 then
			player:setVocation(promotion)
		end
	elseif not promotion then
		player:setVocation(vocation:getDemotion())
	end

	-- Rewards notice
	local rewards = #player:getRewardList()
	if rewards > 0 then
		player:sendTextMessage(MESSAGE_EVENT_ADVANCE, string.format("You have %s %s in your reward chest.", rewards == 1 and 'one' or rewards, rewards > 1 and "rewards" or "reward"))
	end

	-- Update player id 
	local stats = player:inBossFight()
	if stats then
		stats.playerId = player:getId()
	end

	-- Events
	player:registerEvent("PlayerDeath")
	player:registerEvent("Tasks")
	player:registerEvent("AutoLoot")
	player:registerEvent("DropLoot")
	player:registerEvent("BossParticipation")
	player:registerEvent("timeAcess")
	registerCreatureEvent(cid, "PlayerKill")
    player:registerEvent("timeAcessKill") 
	player:registerEvent("Godp")
	player:registerEvent("modalAD")
    player:registerEvent("modalMD")
	registerCreatureEvent(cid, "LuckyPoints")
	player:registerEvent("LuckyPoints")
	player:registerEvent("killpoint")
    player:registerEvent("deathpoint")

	if player:getStorageValue(Storage.combatProtectionStorage) <= os.time() then
		player:setStorageValue(Storage.combatProtectionStorage, os.time() + 10)
		onMovementRemoveProtection(playerId, player:getPosition(), 10)
	end
	db.query('INSERT INTO `players_online` (`player_id`) VALUES (' .. playerId .. ')')

	
	if (player:getStorageValue(789457) == nil) then player:setStorageValue(789457, 0) end
	if (player:getStorageValue(789457) == -1) then player:setStorageValue(789457, 0) end


player:registerEvent("CriticalSystem")

-- Critical System
if player:getCriticalLevel() == -1 then
	player:setCriticalLevel(0)
end
	return true
end
