--: Configurações Gerais  :--
local storage = 32143 --: Storage do script
local msg = "You have found a lucky coin, say !luckycoins for more info." --: Mensagem ao jogador quando recebe uma coin
local showqtd = 1 --: Mostrar QTD de coins na msg? 1-Sim, 0-Não
local qtdtext = "You have" --: Texto que mostra antes da qtd de lucky coins, ex: você pode trocar para 'voce tem'

--: VISUAL :--
local enableeffect = 1 --: Mostrar efeito ao pegar a coin(ajuda a visualizar melhor)? 1 - Sim, 0 - Não.
local effect = CONST_ME_FERUMBRAS --: Efeito para mostrar, só é usado se for habilitado

  --: RATES :--
  local boost = 1 --: Aumenta as chances de obter coins para todos os monstros. 1 = 1x, 2 = 2x etc...
  local anycreature = 1 --: Todas as criaturas podem dropar. 0 - Não, 1 - Sim.
  local anycrate = 15 --: Chance de dropar em qlqr criatura 200 = 0,005%
  local ignorecfg = 1 --: Ignorar as chances da configuração? 1=sim 0=não

  --: Nota: ignorecfg = 1 faz com que todas as chances passem a ser da anycrate, independente da cfg

  --: Altere os monstros, o nome e o a chance de obter a coin  :--
  local config = {
    -- Quanto maior for o valor, menores são as chances de conseguir a coin
    ["Demon"] = {chance = 600}, -- 600 significa a chance de um em 600
    ["Ferumbras"] = {chance = 30}, -- 30 significa a chance de uma em 30... etc
    ["Rat"] = {chance = 1}, -- 100% de chance
    ["Rotworm"] = {chance = 2}, -- 50% de chance
    ["Dog"] = {chance = 10} -- 10% de chance
  }

  function onKill(cid, target, lastHit)
    if (isPlayer(target)) then return true end
    local monster = getCreatureName(target)
    local rand

    if (ignorecfg ~= 1) then
      for index, arraymonster in ipairs(config) do
        if ((arraymonster ~= monster) and (anycreature == 0)) then return true end
      end
      if (((config[monster])) == nil) then rand = anycrate else rand = ((config[monster].chance) / boost) end
    else
      rand = anycrate
    end

    local storageatual = getPlayerStorageValue(cid, storage)
    local plural = "s"
    local qtd = ""
    if (rand < 1) then rand = 1 end
    if (storageatual == 1) then	plural = ""	end
    if (showqtd == 1) then qtd = " " .. qtdtext .. " " .. storageatual + 1 .. " lucky coin" .. plural .. "." end

    if  (math.random(rand) == 1) then
      setPlayerStorageValue(cid, storage, storageatual + 1)
      doPlayerSendTextMessage(cid, MESSAGE_EVENT_ADVANCE, msg .. qtd)
      if (enableeffect == 1) then doSendMagicEffect(getPlayerPosition(cid), effect) end
    end

    return true
  end