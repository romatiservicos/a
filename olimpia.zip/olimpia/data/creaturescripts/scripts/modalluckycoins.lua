--: Configurações Gerais  :--
local storage = 32143 --: Storage do script, a mesma do creaturescript luckypoints.lua e do talk
local modalid = 1053 --: O mesmo valor que na luckycoinstalk


function onModalWindow(player, modalWindowId, buttonId, choiceId)
  player:unregisterEvent("ModalWindow_LuckyCoins")
  if modalWindowId == modalid then
    if buttonId == 100 and choiceId ~= nil and choiceId ~= 255 then
      local itemprice = (lucky_items[ordem[choiceId]].price)
      local pstorage = (player:getStorageValue(storage))
      local itemid = (ordem[choiceId])

      if ((pstorage) >= (itemprice)) then
        player:setStorageValue(storage, (pstorage - itemprice))
        player:addItem(itemid, 1)
        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "Vou comprou um " .. (ItemType(itemid):getName()) .. " por " .. (itemprice) .. " Souls(s)." )
      else
        player:sendCancelMessage('Voce nao tem soul suficiente.')
      end
    end
  end
end