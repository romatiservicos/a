function onDeath(creature, corpse, killer, mostDamage, unjustified, mostDamage_unjustified)
    if creature:isMonster() and CREATURE_BEHAVIOR then
        CREATURE_BEHAVIOR[creature:getId()] = nil
    end
    return true
end