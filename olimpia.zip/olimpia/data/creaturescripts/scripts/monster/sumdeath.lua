function onDeath(creature, corpse, killer, mostDamage, unjustified, mostDamage_unjustified)
    if creature:isMonster() and SUMMON_SAVE then
        local saveId = SUMMON_SAVE[creature:getId()]
        if saveId then
            local save = CREATURE_SAVE[saveId]
            if save then
                save[6] = save[6] and save[6]+1 or 1
                if save[6] >= save[5] then
                    local monster = Game.createMonster(save[2], save[4], false, true)
                    if monster then
                        CREATURE_BEHAVIOR[monster:getId()] = save[1]+1
                        monster:addHealth(save[3]-monster:getHealth())
                    end
                    CREATURE_SAVE[saveId] = nil
                end
                SUMMON_SAVE[creature:getId()] = nil
            end
        end
    end
    return true
end