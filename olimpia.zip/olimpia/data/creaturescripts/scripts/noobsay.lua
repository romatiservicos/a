function onDeath(cid)
         doCreatureSay(cid,"Jovem baiaksjbv.servegame.com o melhor baiak 8.6!",1)         
end