function onLogin(cid)
if getPlayerStorageValue(cid, 200+555884621212) == 1 then -- ID 200
doPlayerAddMount(cid, 6)
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- DRAPTOR
setPlayerStorageValue(cid, 200+555884621212, 2)

elseif getPlayerStorageValue(cid, 210+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Blazebringer
doPlayerAddMount(cid, 9)
setPlayerStorageValue(cid, 210+555884621212, 2)

elseif getPlayerStorageValue(cid, 261+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Crystal Wolf >> 11101  Voce recebera a montaria no jogo.
doPlayerAddMount(cid, 16)
setPlayerStorageValue(cid, 261+555884621212, 2)

elseif getPlayerStorageValue(cid, 201+555884621212) == 1 then 
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.')  -- Dromedary
doPlayerAddMount(cid, 20)
setPlayerStorageValue(cid, 201+555884621212, 2)

elseif getPlayerStorageValue(cid, 205+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Scorpion King
doPlayerAddMount(cid, 21)
setPlayerStorageValue(cid, 205+555884621212, 2)

elseif getPlayerStorageValue(cid, 209+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Armoured War Horse
doPlayerAddMount(cid, 23)
setPlayerStorageValue(cid, 209+555884621212, 2)

elseif getPlayerStorageValue(cid, 206+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.')  -- Shadow Draptor
doPlayerAddMount(cid, 24)
setPlayerStorageValue(cid, 206+555884621212, 2)

elseif getPlayerStorageValue(cid, 204+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Lady bug
doPlayerAddMount(cid, 27)
setPlayerStorageValue(cid, 204+555884621212, 2)

elseif getPlayerStorageValue(cid, 202+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Ironblight
doPlayerAddMount(cid, 29)
setPlayerStorageValue(cid, 202+555884621212, 2)

elseif getPlayerStorageValue(cid, 203+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Magma Crawler
doPlayerAddMount(cid, 30)
setPlayerStorageValue(cid, 203+555884621212, 2)

elseif getPlayerStorageValue(cid, 207+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Crimson Ray
doPlayerAddMount(cid, 33)
setPlayerStorageValue(cid, 207+555884621212, 2)

elseif getPlayerStorageValue(cid, 212+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Steelbeak
doPlayerAddMount(cid, 34)
setPlayerStorageValue(cid, 212+555884621212, 2)

elseif getPlayerStorageValue(cid, 213+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Tombstinger
doPlayerAddMount(cid, 36)
setPlayerStorageValue(cid, 213+555884621212, 2)

elseif getPlayerStorageValue(cid, 214+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Ursagrodon
doPlayerAddMount(cid, 38)
setPlayerStorageValue(cid, 214+555884621212, 2)

elseif getPlayerStorageValue(cid, 211+555884621212) == 2 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Platesaurian
doPlayerAddMount(cid, 37)
setPlayerStorageValue(cid, 211+555884621212, 2)

elseif getPlayerStorageValue(cid, 250+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Hellgrip
doPlayerAddMount(cid, 39)
setPlayerStorageValue(cid, 250+555884621212, 2)

elseif getPlayerStorageValue(cid, 215+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Noble Lion
doPlayerAddMount(cid, 40)
setPlayerStorageValue(cid, 215+555884621212, 2)

elseif getPlayerStorageValue(cid, 208+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Desert King
doPlayerAddMount(cid, 41)
setPlayerStorageValue(cid, 208+555884621212, 2)

elseif getPlayerStorageValue(cid, 266+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Shock Head
doPlayerAddMount(cid, 42)
setPlayerStorageValue(cid, 266+555884621212, 2)

elseif getPlayerStorageValue(cid, 216+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Walker
doPlayerAddMount(cid, 43)
setPlayerStorageValue(cid, 216+555884621212, 2)

elseif getPlayerStorageValue(cid, 217+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Azudocus
doPlayerAddMount(cid, 44)
setPlayerStorageValue(cid, 217+555884621212, 2)

elseif getPlayerStorageValue(cid, 218+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Carpacosaurus
doPlayerAddMount(cid, 45)
setPlayerStorageValue(cid, 218+555884621212, 2)

elseif getPlayerStorageValue(cid, 219+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Death Crawler
doPlayerAddMount(cid, 46)
setPlayerStorageValue(cid, 219+555884621212, 2)

elseif getPlayerStorageValue(cid, 220+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Flamesteed
doPlayerAddMount(cid, 47)
setPlayerStorageValue(cid, 220+555884621212, 2)

elseif getPlayerStorageValue(cid, 221+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Jade Lion
doPlayerAddMount(cid, 48)
setPlayerStorageValue(cid, 221+555884621212, 2)

elseif getPlayerStorageValue(cid, 222+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Jade Pincer
doPlayerAddMount(cid, 49)
setPlayerStorageValue(cid, 222+555884621212, 2)

elseif getPlayerStorageValue(cid, 223+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Nethersteed
doPlayerAddMount(cid, 50)
setPlayerStorageValue(cid, 223+555884621212, 2)

elseif getPlayerStorageValue(cid, 224+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Tempest
doPlayerAddMount(cid, 51)
setPlayerStorageValue(cid, 224+555884621212, 2)

elseif getPlayerStorageValue(cid, 225+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Winter King
doPlayerAddMount(cid, 52)
setPlayerStorageValue(cid, 225+555884621212, 2)

elseif getPlayerStorageValue(cid, 226+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Doombringer
doPlayerAddMount(cid, 53)
setPlayerStorageValue(cid, 226+555884621212, 2)


elseif getPlayerStorageValue(cid, 227+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Woodland Prince
doPlayerAddMount(cid, 54)
setPlayerStorageValue(cid, 227+555884621212, 2)


elseif getPlayerStorageValue(cid, 228+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Hailtorm Fury
doPlayerAddMount(cid, 55)
setPlayerStorageValue(cid, 228+555884621212, 2)

elseif getPlayerStorageValue(cid, 229+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Siegebreaker
doPlayerAddMount(cid, 56)
setPlayerStorageValue(cid, 229+555884621212, 2)


elseif getPlayerStorageValue(cid, 230+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Poisonbane
doPlayerAddMount(cid, 57)
setPlayerStorageValue(cid, 230+555884621212, 2)

elseif getPlayerStorageValue(cid, 231+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Blackpelt
doPlayerAddMount(cid, 58)
setPlayerStorageValue(cid, 231+555884621212, 2)

elseif getPlayerStorageValue(cid, 258+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Golden Dragonfly Voce recebera a montaria no jogo.
doPlayerAddMount(cid, 59)
setPlayerStorageValue(cid, 258+555884621212, 2)

elseif getPlayerStorageValue(cid, 259+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Steel Bee
doPlayerAddMount(cid, 60)
setPlayerStorageValue(cid, 259+555884621212, 2)

elseif getPlayerStorageValue(cid, 260+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Copper Fly
doPlayerAddMount(cid, 61)
setPlayerStorageValue(cid, 260+555884621212, 2)

elseif getPlayerStorageValue(cid, 232+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Tundra Rambler
doPlayerAddMount(cid, 62)
setPlayerStorageValue(cid, 232+555884621212, 2)


elseif getPlayerStorageValue(cid, 233+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Highland Yak
doPlayerAddMount(cid, 63)
setPlayerStorageValue(cid, 233+555884621212, 2)


elseif getPlayerStorageValue(cid, 234+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Glacier Vagabond
doPlayerAddMount(cid, 64)
setPlayerStorageValue(cid, 234+555884621212, 2)


elseif getPlayerStorageValue(cid, 235+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Shadow Hart REPARAR
doPlayerAddMount(cid, 72)
setPlayerStorageValue(cid, 235+555884621212, 2)

elseif getPlayerStorageValue(cid, 236+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Black Stag REPARAR
doPlayerAddMount(cid, 73)
setPlayerStorageValue(cid, 236+555884621212, 2)

elseif getPlayerStorageValue(cid, 237+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Emperor Deer REPARAR
doPlayerAddMount(cid, 74)
setPlayerStorageValue(cid, 237+555884621212, 2)

elseif getPlayerStorageValue(cid, 238+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Flying Divan REPARAR
doPlayerAddMount(cid, 65)
setPlayerStorageValue(cid, 238+555884621212, 2)

elseif getPlayerStorageValue(cid, 239+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Magic Carpet REPARAR
doPlayerAddMount(cid, 66)
setPlayerStorageValue(cid, 239+555884621212, 2)


elseif getPlayerStorageValue(cid, 240+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Floating Kashmir REPARAR
doPlayerAddMount(cid, 67)
setPlayerStorageValue(cid, 240+555884621212, 2)

elseif getPlayerStorageValue(cid, 241+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Ringtail Waccoon REPARAR
doPlayerAddMount(cid, 68)
setPlayerStorageValue(cid, 241+555884621212, 2)


elseif getPlayerStorageValue(cid, 242+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Night Waccoon REPARAR
doPlayerAddMount(cid, 69)
setPlayerStorageValue(cid, 242+555884621212, 2)

elseif getPlayerStorageValue(cid, 243+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Emerald Waccoon REPARAR
doPlayerAddMount(cid, 70)
setPlayerStorageValue(cid, 243+555884621212, 2)

elseif getPlayerStorageValue(cid, 244+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Flitterkatzen
doPlayerAddMount(cid, 75)
setPlayerStorageValue(cid, 244+555884621212, 2)

elseif getPlayerStorageValue(cid, 245+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Venompaw
doPlayerAddMount(cid, 76)
setPlayerStorageValue(cid, 245+555884621212, 2)

elseif getPlayerStorageValue(cid, 246+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Batcat
doPlayerAddMount(cid, 77)
setPlayerStorageValue(cid, 246+555884621212, 2)

elseif getPlayerStorageValue(cid, 247+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Sea Devil
doPlayerAddMount(cid, 78)
setPlayerStorageValue(cid, 247+555884621212, 2)

elseif getPlayerStorageValue(cid, 248+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Coralripper
doPlayerAddMount(cid, 79)
setPlayerStorageValue(cid, 248+555884621212, 2)

elseif getPlayerStorageValue(cid, 249+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Plumfish
doPlayerAddMount(cid, 80)
setPlayerStorageValue(cid, 249+555884621212, 2)

elseif getPlayerStorageValue(cid, 251+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Manta Ray
doPlayerAddMount(cid, 28)
setPlayerStorageValue(cid, 251+555884621212, 2)


elseif getPlayerStorageValue(cid, 252+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Gorongra Voce recebera a montaria no jogo.
doPlayerAddMount(cid, 81)
setPlayerStorageValue(cid, 252+555884621212, 2)


elseif getPlayerStorageValue(cid, 253+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Noctungra
doPlayerAddMount(cid, 82)
setPlayerStorageValue(cid, 253+555884621212, 2)

elseif getPlayerStorageValue(cid, 254+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Silverneck
doPlayerAddMount(cid, 83)
setPlayerStorageValue(cid, 254+555884621212, 2)

elseif getPlayerStorageValue(cid, 255+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Slagsnare
doPlayerAddMount(cid, 84)
setPlayerStorageValue(cid, 255+555884621212, 2)


elseif getPlayerStorageValue(cid, 256+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Nightstinger
doPlayerAddMount(cid, 85)
setPlayerStorageValue(cid, 256+555884621212, 2)

elseif getPlayerStorageValue(cid, 257+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Razorcreep
doPlayerAddMount(cid, 86)
setPlayerStorageValue(cid, 257+555884621212, 2)


elseif getPlayerStorageValue(cid, 262+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Rift Runner
doPlayerAddMount(cid, 87)
setPlayerStorageValue(cid, 262+555884621212, 2)

elseif getPlayerStorageValue(cid, 263+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Nightdweller
doPlayerAddMount(cid, 88)
setPlayerStorageValue(cid, 263+555884621212, 2)

elseif getPlayerStorageValue(cid, 264+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Frostflare
doPlayerAddMount(cid, 89)
setPlayerStorageValue(cid, 264+555884621212, 2)

elseif getPlayerStorageValue(cid, 265+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Cinderhoof
doPlayerAddMount(cid, 90)
setPlayerStorageValue(cid, 265+555884621212, 2)

elseif getPlayerStorageValue(cid, 268+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Mouldpincer
doPlayerAddMount(cid, 91)
setPlayerStorageValue(cid, 268+555884621212, 2)

elseif getPlayerStorageValue(cid, 269+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Bloodcurl
doPlayerAddMount(cid, 92)
setPlayerStorageValue(cid, 269+555884621212, 2)

elseif getPlayerStorageValue(cid, 270+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Leafscuttler
doPlayerAddMount(cid, 93)
setPlayerStorageValue(cid, 270+555884621212, 2)

elseif getPlayerStorageValue(cid, 271+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Racing Bird
doPlayerAddMount(cid, 2)
setPlayerStorageValue(cid, 271+555884621212, 2)

elseif getPlayerStorageValue(cid, 272+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Black Sheep
doPlayerAddMount(cid, 4)
setPlayerStorageValue(cid, 272+555884621212, 2)

elseif getPlayerStorageValue(cid, 267+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- thornfire wolf
doPlayerAddMount(cid, 100)
setPlayerStorageValue(cid, 267+555884621212, 2)


elseif getPlayerStorageValue(cid, 273+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Midnight Panther
doPlayerAddMount(cid, 5)
setPlayerStorageValue(cid, 273+555884621212, 2)

elseif getPlayerStorageValue(cid, 274+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Titanica
doPlayerAddMount(cid, 7)
setPlayerStorageValue(cid, 274+555884621212, 2)

elseif getPlayerStorageValue(cid, 275+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Tin Lizzard
doPlayerAddMount(cid, 8)
setPlayerStorageValue(cid, 275+555884621212, 2)


elseif getPlayerStorageValue(cid, 276+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Sparkion
doPlayerAddMount(cid, 94)
setPlayerStorageValue(cid, 276+555884621212, 2)


elseif getPlayerStorageValue(cid, 277+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Neon Sparkid
doPlayerAddMount(cid, 95)
setPlayerStorageValue(cid, 277+555884621212, 2)


elseif getPlayerStorageValue(cid, 278+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Vortexion
doPlayerAddMount(cid, 96)
setPlayerStorageValue(cid, 278+555884621212, 2)


elseif getPlayerStorageValue(cid, 279+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Swamp Snapper
doPlayerAddMount(cid, 97)
setPlayerStorageValue(cid, 279+555884621212, 2)


elseif getPlayerStorageValue(cid, 280+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Mould Shell
doPlayerAddMount(cid, 98)
setPlayerStorageValue(cid, 280+555884621212, 2)

elseif getPlayerStorageValue(cid, 281+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received mount from VikingTibia Shop.') -- Reed Lurker
doPlayerAddMount(cid, 99)
setPlayerStorageValue(cid, 281+555884621212, 2)
-- Addons --

elseif getPlayerStorageValue(cid, 300+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- barbarian
doPlayerAddOutfit(cid, 147, 3)
doPlayerAddOutfit(cid, 143, 3)
setPlayerStorageValue(cid, 300+555884621212, 2)

elseif getPlayerStorageValue(cid, 301+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- warrior
doPlayerAddOutfit(cid, 142, 3)
doPlayerAddOutfit(cid, 134, 3)
setPlayerStorageValue(cid, 301+555884621212, 2)

elseif getPlayerStorageValue(cid, 302+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- assassin 
doPlayerAddOutfit(cid, 156, 3)
doPlayerAddOutfit(cid, 152, 3)
setPlayerStorageValue(cid, 302+555884621212, 2)

elseif getPlayerStorageValue(cid, 303+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Insectoid
doPlayerAddOutfit(cid, 466, 3)
doPlayerAddOutfit(cid, 465, 3)
setPlayerStorageValue(cid, 303+555884621212, 2)

elseif getPlayerStorageValue(cid, 304+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Summoner
--doPlayerAddOutfit(cid, 141, 3) FEMALE
doPlayerAddOutfit(cid, 133, 3)
setPlayerStorageValue(cid, 304+555884621212, 2)

elseif getPlayerStorageValue(cid, 305+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Entrepreneur
doPlayerAddOutfit(cid, 471, 3)
doPlayerAddOutfit(cid, 472, 3)
setPlayerStorageValue(cid, 305+555884621212, 2)

elseif getPlayerStorageValue(cid, 306+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Mage
doPlayerAddOutfit(cid, 138, 3)
--doPlayerAddOutfit(cid, 130, 3) -- MALE
setPlayerStorageValue(cid, 306+555884621212, 2)

elseif getPlayerStorageValue(cid, 307+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Glooth Engineer
doPlayerAddOutfit(cid, 618, 3)
doPlayerAddOutfit(cid, 610, 3)
setPlayerStorageValue(cid, 307+555884621212, 2)

elseif getPlayerStorageValue(cid, 308+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Champion
doPlayerAddOutfit(cid, 633, 3)
doPlayerAddOutfit(cid, 632, 3)
setPlayerStorageValue(cid, 308+555884621212, 2)

elseif getPlayerStorageValue(cid, 309+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Conjurer
doPlayerAddOutfit(cid, 635, 3)
doPlayerAddOutfit(cid, 634, 3)
setPlayerStorageValue(cid, 309+555884621212, 2)

elseif getPlayerStorageValue(cid, 310+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Beastmaster
doPlayerAddOutfit(cid, 637, 3)
doPlayerAddOutfit(cid, 636, 3)
setPlayerStorageValue(cid, 310+555884621212, 2)

elseif getPlayerStorageValue(cid, 311+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Chaos Acolyte Addon
doPlayerAddOutfit(cid, 665, 3)
doPlayerAddOutfit(cid, 664, 3)
setPlayerStorageValue(cid, 311+555884621212, 2)

elseif getPlayerStorageValue(cid, 312+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Death HeraldAddon
doPlayerAddOutfit(cid, 667, 3)
doPlayerAddOutfit(cid, 666, 3)
setPlayerStorageValue(cid, 312+555884621212, 2)

elseif getPlayerStorageValue(cid, 313+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Ranger
doPlayerAddOutfit(cid, 684, 3)
doPlayerAddOutfit(cid, 683, 3)
setPlayerStorageValue(cid, 313+555884621212, 2)

elseif getPlayerStorageValue(cid, 314+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Ceremonial Garb
doPlayerAddOutfit(cid, 695, 3)
doPlayerAddOutfit(cid, 694, 3)
setPlayerStorageValue(cid, 314+555884621212, 2)

elseif getPlayerStorageValue(cid, 315+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Marionette's Puppeteer
doPlayerAddOutfit(cid, 697, 3)
doPlayerAddOutfit(cid, 696, 3)
setPlayerStorageValue(cid, 315+555884621212, 2)

elseif getPlayerStorageValue(cid, 316+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Spirit Caller
doPlayerAddOutfit(cid, 699, 3)
doPlayerAddOutfit(cid, 698, 3)
setPlayerStorageValue(cid, 316+555884621212, 2)

elseif getPlayerStorageValue(cid, 317+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Evoker
doPlayerAddOutfit(cid, 725, 3)
doPlayerAddOutfit(cid, 724, 3)
setPlayerStorageValue(cid, 317+555884621212, 2)

elseif getPlayerStorageValue(cid, 318+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Seaweaver
doPlayerAddOutfit(cid, 733, 3)
doPlayerAddOutfit(cid, 732, 3)
setPlayerStorageValue(cid, 318+555884621212, 2)


elseif getPlayerStorageValue(cid, 319+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Elementalist
doPlayerAddOutfit(cid, 433, 3)
doPlayerAddOutfit(cid, 432, 3)
setPlayerStorageValue(cid, 319+555884621212, 2)

elseif getPlayerStorageValue(cid, 320+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Deepling
doPlayerAddOutfit(cid, 464, 3)
doPlayerAddOutfit(cid, 463, 3)
setPlayerStorageValue(cid, 320+555884621212, 2)

elseif getPlayerStorageValue(cid, 322+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Druid
doPlayerAddOutfit(cid, 148, 3)
doPlayerAddOutfit(cid, 144, 3)
setPlayerStorageValue(cid, 322+555884621212, 2)


elseif getPlayerStorageValue(cid, 323+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Brotherhood
doPlayerAddOutfit(cid, 279, 3)
doPlayerAddOutfit(cid, 278, 3)
setPlayerStorageValue(cid, 323+555884621212, 2)

elseif getPlayerStorageValue(cid, 324+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Dream Warden
doPlayerAddOutfit(cid, 578, 3)
doPlayerAddOutfit(cid, 577, 3)
setPlayerStorageValue(cid, 324+555884621212, 2)


elseif getPlayerStorageValue(cid, 325+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Hunter 
doPlayerAddOutfit(cid, 137, 3)
doPlayerAddOutfit(cid, 129, 3)
setPlayerStorageValue(cid, 325+555884621212, 2)


elseif getPlayerStorageValue(cid, 326+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Nobleman
doPlayerAddOutfit(cid, 140, 3)
doPlayerAddOutfit(cid, 132, 3)
setPlayerStorageValue(cid, 326+555884621212, 2)

elseif getPlayerStorageValue(cid, 327+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Norsewoman/Norseman
doPlayerAddOutfit(cid, 140, 3)
doPlayerAddOutfit(cid, 251, 3)
setPlayerStorageValue(cid, 327+555884621212, 2)

elseif getPlayerStorageValue(cid, 329+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Recruiter
doPlayerAddOutfit(cid, 746, 3)
doPlayerAddOutfit(cid, 745, 3)
setPlayerStorageValue(cid, 329+555884621212, 2)


elseif getPlayerStorageValue(cid, 330+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Sea Dog Outfits
doPlayerAddOutfit(cid, 750, 3)
doPlayerAddOutfit(cid, 749, 3)
setPlayerStorageValue(cid, 330+555884621212, 2)


elseif getPlayerStorageValue(cid, 331+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Royal Pumpkin
doPlayerAddOutfit(cid, 760, 3)
doPlayerAddOutfit(cid, 759, 3)
setPlayerStorageValue(cid, 331+555884621212, 2)

elseif getPlayerStorageValue(cid, 332+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Rift Warrior
doPlayerAddOutfit(cid, 846, 3)
doPlayerAddOutfit(cid, 845, 3)
setPlayerStorageValue(cid, 332+555884621212, 2)

elseif getPlayerStorageValue(cid, 333+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Winter Warden
doPlayerAddOutfit(cid, 853, 3)
doPlayerAddOutfit(cid, 852, 3)
setPlayerStorageValue(cid, 333+555884621212, 2)

elseif getPlayerStorageValue(cid, 334+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Philosopher
doPlayerAddOutfit(cid, 874, 3)
doPlayerAddOutfit(cid, 873, 3)
setPlayerStorageValue(cid, 334+555884621212, 2)


elseif getPlayerStorageValue(cid, 335+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Nightmare
doPlayerAddOutfit(cid, 268, 3)
doPlayerAddOutfit(cid, 269, 3)
setPlayerStorageValue(cid, 335+555884621212, 2)

elseif getPlayerStorageValue(cid, 336+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Wayfarer
doPlayerAddOutfit(cid, 366, 3)
doPlayerAddOutfit(cid, 367, 3)
setPlayerStorageValue(cid, 336+555884621212, 2)


elseif getPlayerStorageValue(cid, 337+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Crystal Warlord
doPlayerAddOutfit(cid, 512, 3)
doPlayerAddOutfit(cid, 513, 3)
setPlayerStorageValue(cid, 337+555884621212, 2)

elseif getPlayerStorageValue(cid, 338+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Soil Guardian
doPlayerAddOutfit(cid, 514, 3)
doPlayerAddOutfit(cid, 516, 3)
setPlayerStorageValue(cid, 338+555884621212, 2)

elseif getPlayerStorageValue(cid, 339+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Cave Explorer
doPlayerAddOutfit(cid, 574, 3)
doPlayerAddOutfit(cid, 575, 3)
setPlayerStorageValue(cid, 339+555884621212, 2)


elseif getPlayerStorageValue(cid, 340+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- Pirate
doPlayerAddOutfit(cid, 151, 3)
doPlayerAddOutfit(cid, 155, 3)
setPlayerStorageValue(cid, 340+555884621212, 2)

elseif getPlayerStorageValue(cid, 341+555884621212) == 1 then
doPlayerSendTextMessage(cid, 18, 'You received addon full from VikingTibia Shop.') -- New Outfit
doPlayerAddOutfit(cid, 884, 3)
doPlayerAddOutfit(cid, 885, 3)
setPlayerStorageValue(cid, 341+555884621212, 2)
	end
 	return TRUE
end