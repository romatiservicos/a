local firstItems = {}
firstItems[0] =
{
2173,     --aol
23546,     -- shield
2190,   --wand
2124,     -- ring
2457,     -- helmet
2647,      -- legs
2463       -- armor
}
firstItems[1] =
{
2173,     --aol
23546,     -- shield
2190,   --wand
2124,     -- ring
2457,     -- helmet
2647,      -- legs
2463       -- armor
}
firstItems[2] =
{
2173,     --aol
23546,     -- shield
2182,   -- rod
2124,     -- ring
2457,     -- helmet
2647,      -- legs
2463       -- armor
}
--paladin
firstItems[3] =
{
2173,     --aol
23546,     -- shield
2389,     --spear
2124,     -- ring
2457,     -- helmet
2647,      -- legs
2463       -- armor
}
firstItems[4] =
{
2173,     --aol
23546,     -- shield
2428,       -- axe
2439,     --club
2383,     --sword
2124,     -- ring
2457,     -- helmet
2647,      -- legs
2463       -- armor
}

function onLogin(cid)
if getPlayerStorageValue(cid, 30001) == -1 then
local bag = doPlayerAddItem(cid, 5926, 1)
doAddContainerItem(bag, 2160, 1)
doAddContainerItem(bag, 2554, 1)
doAddContainerItem(bag, 2120, 1)
doAddContainerItem(bag, 7618, 1)
doAddContainerItem(bag, 2789, 100)
setPlayerStorageValue(cid, 30001, 1)
end
return TRUE
end