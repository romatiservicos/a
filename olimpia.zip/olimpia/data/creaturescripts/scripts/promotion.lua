local config = {
  level = 20
}
 
function onAdvance(player, skill)
  local vocation = player:getVocation()
  local promotion = vocation:getPromotion()
  local vocName = player:getVocation():getName()
  if player:isPlayer() and skill == SKILL_LEVEL then
      if player:getLevel() == config.level then
          player:setVocation(promotion)
          player:sendTextMessage(MESSAGE_STATUS_WARNING, "Voce ganhou experiencia suficiente para ser promovido.\nAgora voce e um " ..vocName.. ".", Player.getPosition())
     end
  end
end