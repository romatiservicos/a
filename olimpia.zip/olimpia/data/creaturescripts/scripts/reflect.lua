function getItemReflectPercent(itemuid)

	return getItemAttribute(itemuid, "reflectPercent")

end

function doPlayerAddReflectedItem(cid, 2521, 50)

local item = doPlayerAddItem(cid, 2521)

doItemSetAttribute(item, "description", "[Reflect: "..percent.."%]")

doItemSetAttribute(item, "reflectPercent", percent)

end