function onLogout(cid)

   if player:getStorageValue(cid, 789456) ~= -1 then
       player:setStorageValue(cid, 789456, player:getStorageValue(cid, 789456)-os.time())
   end
return true
end