local config = {
message = "Congrulations. Teleport close in 1 minute",
timeToRemove = 60, -- seconds
teleportId = 1387,
bosses = {
["Magician"] = { x = 459, y = 594, z = 7 },

}
}

local function removal(position)
local teleport = Tile(position):getItemById(1387)
if teleport then
    teleport:remove()                               
    end
end

function onDeath(cid, corpse, killer)
registerCreatureEvent(cid, "teleportmonster")
local position = getCreaturePosition(cid)

for name, pos in pairs(config.bosses) do
if name == getCreatureName(cid) then
teleport = doCreateTeleport(config.teleportId, pos, position)
doCreatureSay(cid, config.message, TALKTYPE_ORANGE_1)
addEvent(removal, config.timeToRemove * 1000, position)
doSendMagicEffect(position,10)
end
end
return TRUE
end