local config = {
message = "Parabens! O teleport vai fechar em 20 segundos",
timeToRemove = 20, -- seconds
teleportId = 1387,
bosses = {
["Jack Sparrow"] = { x = 65, y = 745, z = 10 },

}
}

local function removal(position)
local teleport = Tile(position):getItemById(1387)
if teleport then
    teleport:remove()                               
    end
end

function onDeath(cid, corpse, killer)
registerCreatureEvent(cid, "teleportmonster")
local position = getCreaturePosition(cid)

for name, pos in pairs(config.bosses) do
if name == getCreatureName(cid) then
teleport = doCreateTeleport(config.teleportId, pos, position)
doCreatureSay(cid, config.message, TALKTYPE_ORANGE_1)
addEvent(removal, config.timeToRemove * 1000, position)
doSendMagicEffect(position,10)
end
end
return TRUE
end