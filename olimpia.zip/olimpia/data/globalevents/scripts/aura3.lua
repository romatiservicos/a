function onThink(interval, lastExecution)
         for _, name in ipairs(getOnlinePlayers()) do
         local cid = getPlayerByName(name)
               if getPlayerVocation(cid) ==9 then
                local player = Player(cid)
                player:say('', TALKTYPE_MONSTER_SAY)
				player:getPosition():sendMagicEffect(CONST_ME_MORTAREA)
               end
         end
         return true
end
