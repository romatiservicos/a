-- ELERA TIBIA 

function onThink(interval, lastExecution)
    local MESSAGE = {
        "[COMANDOS] !kills - !bless - !aol - !buyhouse - !sellhouse - !serverinfo - !online - !uptime - !exp - !outfit .",
        "[CLIENTE ATUALIZADO] http://baiakmirror.com/?subtopic=downloads Use nosso cliente proprio, evite debugs e aproveite nossos sistemas unicos.",
		"[FACEBOOK] https://www.facebook.com/baiakmirror/",
    }
    Game.broadcastMessage(MESSAGE[math.random(1, #MESSAGE)], MESSAGE_EVENT_ADVANCE) 
    return true
end