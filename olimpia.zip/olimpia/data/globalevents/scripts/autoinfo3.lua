function onThink(interval, lastExecution)
  -- Configura��es
    local cor = 22 -- Defina a cor da mensagem (22 = branco)
    local mensagens = {"Upou Ate Lv 700? Quer ser o jogador mais poderoso? Diga !reset e ganhe diversos bonus al�m de uma Area Exclusiva. Para ver os Reset's digite !myresets "} -- Defina as mensagens de propaganda
  -- Fim de Configura��es

  doBroadcastMessage(mensagens[math.random(1,table.maxn(mensagens))], cor)
return TRUE
end