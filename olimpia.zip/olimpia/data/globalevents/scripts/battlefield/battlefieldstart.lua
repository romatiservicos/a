function onStartup()
	Game.setStorageValue(_Lib_Battle_Info.TeamOne.storage, 0)
	Game.setStorageValue(_Lib_Battle_Info.TeamTwo.storage, 0)
	Game.setStorageValue(_Lib_Battle_Info.storage_count, 0)
	return true
end
