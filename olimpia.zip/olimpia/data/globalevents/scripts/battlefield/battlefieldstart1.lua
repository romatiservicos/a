function onStartup()
	Game.setStorageValue(_Lib_Battle_Info1.TeamOne1.storage1, 0)
	Game.setStorageValue(_Lib_Battle_Info1.TeamTwo1.storage1, 0)
	Game.setStorageValue(_Lib_Battle_Info1.storage_count1, 0)
	return true
end
