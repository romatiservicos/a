function onLogin(cid)

doPlayerPopupFYI("Seja bem vindo ao Alissow OTs!
 
Utilize o canal help para maiores informa��es.
 
Enjoy xD")
return TRUE

end