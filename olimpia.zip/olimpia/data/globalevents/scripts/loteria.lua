-- <globalevent name="Loteria1" time="09:00:00" script="loteria.lua" />

local rewards = {
	{2494, 1},
	{2472, 1},
	{2160, 22},
}

function onTime(interval)
	local players = Game.getPlayers()
	
	if #players > 0 and #rewards > 0 then
		local uid, n = math.random(1, #players), math.random(1, #rewards)
		local ganhador = players[uid]
		local reward, count = rewards[n][1], rewards[n][2]
		
		if ganhador and reward and count then
			ganhador:addItem(reward, count)
			Game.broadcastMessage('O player '.. ganhador:getName()..' recebeu '.. count .. ' '..ItemType(reward):getName()..' da loteria.', MESSAGE_STATUS_WARNING)
		end
	end
	
	return true
end