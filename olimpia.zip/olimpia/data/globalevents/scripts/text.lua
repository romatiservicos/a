local effects = {
    {position = Position(163, 52, 7), text = 'HUNTS', effect = CONST_ME_MORTAREA},
	{position = Position(161, 52, 7), text = 'QUESTS', effect = CONST_ME_MORTAREA},
	{position = Position(147, 50, 7), text = 'ADDONS', effect = CONST_ME_MORTAREA},
	{position = Position(147, 52, 7), text = 'VOID CASTLE', effect = CONST_ME_MORTAREA},
	{position = Position(147, 54, 7), text = 'THANA', effect = CONST_ME_MORTAREA},
	{position = Position(147, 43, 7), text = 'OLIMPO', effect = CONST_ME_MORTAREA},
	{position = Position(143, 50, 7), text = 'ASGARD', effect = CONST_ME_MORTAREA},
	{position = Position(151, 43, 7), text = 'ARENA PVP', effect = CONST_ME_MORTAREA},
	{position = Position(154, 40, 7), text = 'EVENTOS', effect = CONST_ME_MORTAREA},
	{position = Position(165, 42, 7), text = 'GUILD CASTLE', effect = CONST_ME_MORTAREA},
	{position = Position(165, 52, 7), text = 'DRAILON', effect = CONST_ME_MORTAREA},
	{position = Position(163, 42, 7), text = 'ISLAND', effect = CONST_ME_MORTAREA},
	{position = Position(151, 45, 7), text = 'PRIVATE', effect = CONST_ME_MORTAREA},
	{position = Position(315, 172, 7), text = 'TEMPLO', effect = CONST_ME_MORTAREA},
}
 
function onThink(interval)
    for i = 1, #effects do
        local settings = effects[i]
        local spectators = Game.getSpectators(settings.position, false, true, 7, 7, 5, 5)
        if #spectators > 0 then
            if settings.text then
                for i = 1, #spectators do
                    spectators[i]:say(settings.text, TALKTYPE_MONSTER_SAY, false, spectators[i], settings.position)
                end
            end
            if settings.effect then
                settings.position:sendMagicEffect(settings.effect)
            end
        end
    end
   return true
end