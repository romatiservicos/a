ZE = -- Zumbi Event
{
	tpOpen = {x = 99, y = 180, z = 7}, -- posi��o de onde abrir� o teleport para entrar no evento.
	tpTimeOpen = 10, -- tempo que o tp ficar� aberto (em minutes).
	posEnterEvent = {x = 38, y = 258, z = 7}, -- posi��o de onde os players ir�o para dentro do evento.
	reward = {21399, 1, "You won Golden Raid Token."}, -- recompensa: "itemid, quantidade, msg"
	storage = 88789,
}