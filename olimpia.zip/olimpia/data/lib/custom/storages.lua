-- STORAGES --
-- (HIGHLY RECOMMENDED -> ONE mission per STORAGE) --
-- Sort it in Values -

Storage = {
	combatProtectionStorage = 50722,
}
